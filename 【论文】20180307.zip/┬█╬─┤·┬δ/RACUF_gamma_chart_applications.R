# -------------------------------------------------- #
# Loading required packages and functions
# -------------------------------------------------- #
require(survival)
require(flexsurv)

#
# Set the working directory to this file location, and then run the following.
#
source("C:/Users/Administrator/Desktop/MonitoringTimeToEvent_ReproducibleResearch/codes/Functions/RAST_RACUF_weibull_functions.R")

#
# Compiled code in C to improve the speed of the optimization of control limits
#
# If Windows system is used, run the following:
dyn.load("C:/Users/Administrator/Desktop/MonitoringTimeToEvent_ReproducibleResearch/C_program/Windows//RAST_RACUF_weibull_app.dll")

#
#install package smcure
#
require("smcure")
data("bmt")

# -------------------------------------------------- #
# Simulated datasets - Paper ----
# -------------------------------------------------- #

#
# Data with cure fraction
#
set.seed(124)
#产生200个受控样本和100个失控样本
dataset0 <- RACUF_gengamma_data(200, 4, 40, 80, -0.77) 
dataset1 <- RACUF_gengamma_data(100, 4, 0.7 * 40, 80, -0.77)
dataset_monit1 <- rbind(dataset0$dataset, dataset1$dataset)
#查看生成数据集的结构
head(dataset_monit1)
#数据集、观测个数、观测变化敏感度、控制线、回归模型的正则表达式


#
#无治愈情况
#
set.seed(123)
dataset0 <- RAST_gengamma_data(200, 4, 40, 40, -0.5) #这是模拟出来的数据，直接用e1684换一下
dataset1 <- RAST_gengamma_data(100, 4, 0.7 * 40, 40, -0.5)
dataset_monit2 <- rbind(dataset0, dataset1)
1 - mean(dataset0$status)

#
# 控制线
#


RACUF_rho07 <- RACUF_gengamma_esti(dataset_monit1[1:200,],Surv(time, status) ~ V3+0)
set.seed(123)
simula1 <- RACUF_h(dataset_monit1[1:200,], Surv(time, status) ~ V3+0, 
                   1000, 10000, 200, RACUF_rho07, 0.7)
simula1

RAST_rho07 <- RAST_gengamma_esti(dataset_monit1[1:200,],Surv(time, status) ~ V3)
set.seed(123)
simula2 <- RAST_h(dataset_monit1[1:200,], Surv(time, status) ~ V3, 
                  1000, 10000, 200, RAST_rho07, 0.7)
simula2


# Examples
set.seed(123)
(simu1 <- simula_h(dataset_monit1[1:200,], 1000, 10000, 200, 0.7, ARL0 = 1000, 
                   form1 = Surv(time, status) ~ V3 + 0, form2 = Surv(time, status) ~ V3))

set.seed(123)
(simu2 <- simula_h(dataset_monit2[1:200,], 1000, 10000, 200, 0.7, ARL0 = 1000, 
                   form1 = Surv(time, status) ~ V3 + 0, form2 = Surv(time, status) ~ V3))



#
# Simulating data to mimic the figures of application data ----
#
#
# Data with cure fraction
#
seed_set <- 123
n0 <- 975
n <- 3378
alpha <- 2
lambda <- 15
beta <- 2
tau <- 19
change <- 1.1

set.seed(seed_set)
dataset_train <- RACUF_gengamma_data(n0, alpha, lambda, tau, beta)
dataset_monit <- RACUF_gengamma_data(n-n0, alpha, change * lambda, tau, beta)
dataset_app <- rbind(dataset_train$dataset, dataset_monit$dataset)

km <- survfit(Surv(time,status)~1, dataset_train$dataset)

#
# Figure 1 ----
#
plot(km,conf.int = F, mark.time = T, xlab = "Time (years)", ylab = "Survival")

#
# 控制线
#
m <- 1000
samples_size <- 20000
ARL0_target <- 2000
formu1 <- Surv(time, status) ~ V3 + 0
formu2 <- Surv(time, status) ~ V3

set.seed(seed_set)
(simulation01 <- simula_h(dataset_app[1:n0,], m, samples_size, n0, 1.1, ARL0 = ARL0_target, 
                          form1 = formu1, form2 = formu2, h_des = 2))


set.seed(seed_set)
(simulation02 <- simula_h(dataset_app[1:n0,], m, samples_size, n0, 0.9, ARL0 = ARL0_target, 
                          form1 = formu1, form2 = formu2, h_des = 2))


RAST_rho11 <- RAST_gengamma_esti(dataset_app[1:n0,], formu2)
RACUF_r11 <- RACUF_gengamma_esti(dataset_app[1:n0,], formu1)

# n0 = 975
# RAST
RAST_CUSUM_rho09 <- -gengamma_rast_alt(dataset_app, formu2, RAST_rho11, 0.9)
RAST_CUSUM_rho11 <- gengamma_rast_alt(dataset_app, formu2, RAST_rho11, 1.1)

y_lim1 <- c(min(- simulation02$h_RAST,min(RAST_CUSUM_rho09)) - 1.1,
            max(simulation01$h_RAST,max(RAST_CUSUM_rho11)) + 0.1)

# RACUF
RACUF_CUSUM_rho09 <- -gengamma_racuf_alt(dataset_app, formu1, RACUF_r11, 0.9)
RACUF_CUSUM_rho11 <- gengamma_racuf_alt(dataset_app, formu1, RACUF_r11, 1.1)

y_lim2 <- c(min(- simulation02$h_RACUF,min(RACUF_CUSUM_rho09)) - 1.1,
            max(simulation01$h_RACUF,max(RACUF_CUSUM_rho11)) + 0.1)


y_lim <- range(c(y_lim1,y_lim2))

#
# Figure 2 (a) ----
#

plot(RACUF_CUSUM_rho11, type = "o", pch = 16, cex = 0.1, 
     ylab = expression(Z[i]), xlab="Observation", ylim = c(y_lim), cex.lab = 0.9)
abline(h = simulation01$h_RACUF, col="black", lwd=1.2,lty=2)

lines(RACUF_CUSUM_rho09, type = "o", pch = 16, cex = 0.1)
abline(h = - simulation02$h_RACUF, col = "black", lwd = 1.2, lty = 2)
abline(h = 0, col = "black", lwd = 1)
abline(v = 975, col = "black", lwd = 1,lty = 3)
text(3000 - 100, 1.2 + simulation01$h_RACUF, 
     bquote(h == .(round(simulation01$h_RACUF,2))),cex=1)
text(3000 - 100, - 1 - simulation02$h_RACUF, 
     bquote(h == .(round(-simulation02$h_RACUF,2))),cex=1)

#
# First 10 signals
#
which(RACUF_CUSUM_rho11 > simulation01$h_RACUF)[1:10]
which(RACUF_CUSUM_rho09 < -simulation02$h_RACUF)


#
# Figure 2 (b) ----
#

plot(RAST_CUSUM_rho11, type = "o", pch = 16, cex = 0.1, 
     ylab = expression(Z[i]), xlab = "Observation", ylim = y_lim, cex.lab = 0.9)
abline(h = simulation01$h_RAST, col="black", lwd = 1.2,lty = 2)

lines(RAST_CUSUM_rho09,type="o", pch = 16, cex = 0.1)
abline(h = - simulation02$h_RAST, col = "black", lwd=1.2, lty=2)
abline(h = 0, col = "black", lwd=1)
abline(v = 975, col="black", lwd=1,lty=3)
text(3000 - 100, 1 + simulation01$h_RAST,
     bquote(h == .(round(simulation01$h_RAST,2))))
text(3000 - 100, - 0.8 - simulation02$h_RAST,
     bquote(h == .(round(-simulation02$h_RAST,2))))

#
# First 10 signals
#
(which(RAST_CUSUM_rho11 > simulation01$h_RAST))[1:10] 
which(RAST_CUSUM_rho09 < -simulation02$h_RAST)



