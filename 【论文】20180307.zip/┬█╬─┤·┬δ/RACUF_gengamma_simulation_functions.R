alert_hour <- function(x, freq = 0.5) {
  
  # ----------------------------------------------------------------------------- #
  # Title: alert_hour
  # ----------------------------------------------------------------------------- #
  # Gengamma
  # ----------------------------------------------------------------------------- #
  # Description: Function to print the time of conclusion of a procedure and give
  #               a sound signal to alert
  # ----------------------------------------------------------------------------- #
  # Usage:  alert_hour(x, freq)
  #
  #         x: number of times to repeat the sound alert
  #         freq: the frequency of sound signal (the seconds between two signals)
  # ----------------------------------------------------------------------------- #
  
  print(Sys.time())
  for(k in 1:x){
    Sys.sleep(freq)
    beep(1)
  }
}

alert_sound <- function(x, freq = 0.5) {
  
  # ----------------------------------------------------------------------------- #
  # Title: alert_sound
  # ----------------------------------------------------------------------------- #
  # Author: Jocel?nio W. Oliveira
  # ----------------------------------------------------------------------------- #
  # Description: Function to give a sound signal to alert when a procedure concludes
  # ----------------------------------------------------------------------------- #
  # Usage:  alert_sound(x, freq)
  #
  #         x: number of times to repeat the sound alert
  #         freq: the frequency of sound signal (the seconds between two signals)
  # ----------------------------------------------------------------------------- #
  for(k in 1:x){
    Sys.sleep(freq)
    beep(1)
  }
}


#
#
#
golden.section.search <- function(f, lower.bound, upper.bound, tolerance) {
  
  # ----------------------------------------------------------------------------- #
  # Title: golden.section.search
  # ----------------------------------------------------------------------------- #
  # Author: Eric Cai (obtained from https://chemicalstatistician.wordpress.com/ )
  # ----------------------------------------------------------------------------- #
  # Description: Optimizes (minimization) a function using the Golden Ratio method
  # ----------------------------------------------------------------------------- #
  # Usage:  golden.section.search(f, lower.bound, upper.bound, tolerance)
  # 
  #         f: the function to be optimized
  #         lower.bound: the lower limit of the search interval
  #         upper.bound: the upper limit of the search interval
  #         tolerance: the accuracy of optimization
  # ----------------------------------------------------------------------------- #
  # Value:  minimum: the point that minimizes the function
  # ----------------------------------------------------------------------------- #
  
  golden.ratio <- 2 / (sqrt(5) + 1)
  
  ## Use the golden ratio to set the initial test points
  x1 <- upper.bound - golden.ratio * (upper.bound - lower.bound)
  x2 <- lower.bound + golden.ratio * (upper.bound - lower.bound)
  
  ## Evaluate the function at the test points
  f1 <- f(x1)
  f2 <- f(x2)
  
  iteration <- 0
  
  while (abs(upper.bound - lower.bound) > tolerance) {
    iteration <- iteration + 1
    
    if (f2 > f1) {
      # then the minimum is to the left of x2
      # let x2 be the new upper bound
      # let x1 be the new upper test point
      
      ## Set the new upper bound
      upper.bound <- x2
      
      ## Set the new upper test point
      ## Use the special result of the golden ratio
      x2 <- x1
      
      f2 <- f1
      
      # Set the new lower test point
      x1 <- upper.bound - golden.ratio * (upper.bound - lower.bound)
      
      f1 <- f(x1)
    } else {
      
      # the minimum is to the right of x1
      # let x1 be the new lower bound
      # let x2 be the new lower test point
      
      # Set the new lower bound
      lower.bound <- x1
      
      # Set the new lower test point
      x1 <- x2
      
      f1 <- f2
      
      # Set the new upper test point
      x2 <- lower.bound + golden.ratio * (upper.bound - lower.bound)
      
      f2 <- f(x2)
    }
  }
  
  # Use the mid-point of the final interval as the estimate of the optimzer
  
  estimated.minimizer <- (lower.bound + upper.bound) / 2
  
  return(list(minimum = estimated.minimizer))
}
#
#
#


#
# Gengammabull
#
# Some parameters considered
#
# a     : alpha, the form parameter
# b     : lambda, the scale parameter
# tau   : value to generate censoring times from a uniform distribuition on (0, tau)
# beta  : vector of regression parameters for the Promotion Time Model
# gama  : vector of regression parameters for the Accelerated Failure Time Model
# rho1  : intensity of change



#
#
#
RAST_score_gengamma <- function(t, u, d, r, a, b, l) {
  
  # ----------------------------------------------------------------------------- #
  # Title: RAST_score_gengamma
  # ----------------------------------------------------------------------------- #
  # Gengamma
  # ----------------------------------------------------------------------------- #
  # Description: Function to calculate the W_i scores for Gengammabull RAST CUSUM chart
  #               
  # ----------------------------------------------------------------------------- #
  # Usage:  RAST_score_gengamma(t, u, d, r, a, b, l)
  #         
  #         t: observed times
  #         u: the covariates (it can be the complete matrix)
  #         d: censoring indicator (delta)
  #         r: intensity of change to be monitored
  #         a: alpha, form parameter
  #         b: regression parameter beta (= - gamma)
  #         l: lambda, scale parameter
  # ----------------------------------------------------------------------------- #
  # Value:  the W_i scores for RAST CUSUM chart
  # ----------------------------------------------------------------------------- #
  
  return(
    (1 - r ^ (- a)) * ((t * exp( u %*% b) / l) ^ a) - d * a * log(r)
  )
}
#
#
#



#
#
#
RAST_gengamma_estimate <- function(dataset, formula) {
  
  # ----------------------------------------------------------------------------- #
  # Title: RAST_gengamma_estimate
  # ----------------------------------------------------------------------------- #
  # Gengamma
  # ----------------------------------------------------------------------------- #
  # Description: Function to estimate the parameters for Gengammabull RAST CUSUM chart
  # ----------------------------------------------------------------------------- #
  # Usage:  RAST_gengamma_estimate(dataset, formula)
  #         
  #         dataset: the data
  #         formula: a formula expression for regression models returned by the Surv 
  #                   function. Example -> Surv(time, status) ~ V3
  # ----------------------------------------------------------------------------- #
  # Value:  alpha: estimate of the form parameter alpha
  #         lambda: estimate of the scale parameter lambda
  #         beta: estimate of regression paremeters (beta)
  # ----------------------------------------------------------------------------- #
  
  ncovs <- length(dataset) - 2
  MTFA <- survreg(formula, dataset, dist = 'gengammabull')
  mi.est <- MTFA$coe[1]
  sigma.est <- MTFA$sca
  lambda.est <- exp(mi.est)
  alpha.est <- 1 / sigma.est
  gama.est <- MTFA$coe[2:(1 + ncovs)]
  beta <- - gama.est
  list(alf = alpha.est, lam = lambda.est, bet = beta)
}
#
#
#



#
#
#
RACUF_score_gengamma <- function(t, d, bet, alf, lam, rho1, x) {
  
  # ----------------------------------------------------------------------------- #
  # Title: RACUF_score_gengamma
  # ----------------------------------------------------------------------------- #
  # Gengamma
  # ----------------------------------------------------------------------------- #
  # Description: Function to calculate the W_i scores for Gengammabull RACUF CUSUM chart
  # ----------------------------------------------------------------------------- #
  # Usage:  RACUF_score_gengamma(t, d, bet, alf, lam, rho1, x)
  #         
  #         t: observed time
  #         d: censoring indicator (delta)
  #         bet: regression parameter
  #         alf: form parameter, alpha
  #         lam: scale parameter, lambda
  #         rho1: the intesity of change in the quality
  #         x: the covariates
  #
  # ----------------------------------------------------------------------------- #
  # Value:  the RACUF CUSUM scores (W_i)
  # ----------------------------------------------------------------------------- #
  
  quant <- (t / lam) ^ alf
  
  res <- d * (- alf * log(rho1) + quant * (1 - rho1 ^ (- alf))) - 
    exp(x %*% bet) * (- exp(- quant * rho1 ^ (- alf)) + (exp(- quant)))
  return(as.numeric(res))
}
#
#
#



#
#
#
RACUF_gengamma_estimate <- function(dataset, inipar = NULL) {
  
  # ----------------------------------------------------------------------------- #
  # Title: RACUF_gengamma_estimate
  # ----------------------------------------------------------------------------- #
  # Gengamma
  # ----------------------------------------------------------------------------- #
  # Description: Function to estimate the parameters of the Gengammabull RACUF CUSUM 
  #               chart for a given dataset
  # ----------------------------------------------------------------------------- #
  # Usage:  RACUF_gengamma_estimate(dataset, inipar = NULL)
  #
  #         dataset: the data used to estimate
  #         inipar: initial values for the parameters to optimize, with the following
  #                   parameterisation (log(alpha), - alpha * log(lambda), beta)
  #
  # ----------------------------------------------------------------------------- #
  # Value:  result: the result of the parameters in the optim function
  #         estimates: the estimates of the original parameters
  #         fc: estimated cure fraction
  #         maxLogLik: maximum log-likelihood
  #         par.ini: initial values for the parameters in optim (BFGS)
  # ----------------------------------------------------------------------------- #
  
  lb <- ncol(dataset) - 2
  lt <- lb + 2
  
  respar <- rep(0, lt)
  
  if(!is.null(inipar)) {
    if(length(inipar) != lt) cat("Initial vector must have size ", lt,"\n")
    else respar <- inipar
  }
  
  amostra <- dataset$time
  delta <- dataset$status
  covar <- as.matrix(dataset[, 3:lt])
  n <- length(amostra)
  
  loglik_marg <- function(theta){
    rho <- exp(theta[1])
    gam <- theta[2]
    beta <- theta[3:lt]
    resp <- 
      delta * (covar %*% beta + gam + log(rho * (amostra) ^ (rho - 1)) - 
                 (amostra) ^ rho * exp(gam)) -
      (exp(covar %*% beta) * (1 - exp(- (amostra) ^ rho * exp(gam))))
    return(sum(resp))
  }
  
  par.ini <- respar
  result <- optim(respar, loglik_marg, control = list(fnscale = - 1), method = "BFGS", 
                  hessian = T)
  resul <- result$par
  # Original parameters
  a_est <- exp(resul[1])  # form -> alpha
  b_est <- exp(- resul[2] / a_est) # scale -> lambda
  beta_est <- resul[3:lt]
  covari <- covar
  fc_est <- mean(exp(- exp(covari %*% beta_est)))
  list(result = resul,
       estimates = as.numeric(c(a_est, b_est, beta_est)),
       fc = (fc_est),
       maxLogLik = result$value,
       par.ini = par.ini)
  
}
#
#
#



#
#
#
gengamma_RACUF_alt <- function(dataset, estima, rho1) {
  
  # ----------------------------------------------------------------------------- #
  # Title: gengamma_RACUF_alt
  # ----------------------------------------------------------------------------- #
  # Gengamma
  # ----------------------------------------------------------------------------- #
  # Description: Alternative function to calculate Gengammabull RACUF CUSUM scores
  # ----------------------------------------------------------------------------- #
  # Usage:  gengamma_RACUF_alt(dataset, estima, rho1)
  # 
  #         dataset: the data
  #         estima: object returned by the function 'RACUF_gengamma_estimate'
  #         rho1: intensity of change
  # ----------------------------------------------------------------------------- #
  # Value:  the RACUF CUSUM scores
  # ----------------------------------------------------------------------------- #
  
  ndataset <- nrow(dataset)
  lt <- ncol(dataset)
  lb <- lt - 2
  
  alpha_0 <- estima$estimates[1]
  lambda_0 <-  estima$estimates[2]
  beta_0 <- estima$estimates[3:lt]
  
  cusum <- vector()
  cusum[1] <- 0
  
  wi <- RACUF_score_gengamma(dataset$time, dataset$status, beta_0, alpha_0, lambda_0, 
                             rho1, dataset[, 3:lt])
  for(i in 2:(ndataset + 1)){
    cusum[i] <- max(0, cusum[i - 1] + wi[i - 1])
  }
  
  list(cusum = cusum, cure_est = estima$fc)
  
}
#
#
#



#
#
#
gengamma_RAST_alt <- function(dataset, estima, rho1) {
  
  
  # ----------------------------------------------------------------------------- #
  # Title: gengamma_RAST_alt
  # ----------------------------------------------------------------------------- #
  # Gengamma
  # ----------------------------------------------------------------------------- #
  # Description: Alternative function to calculate Gengammabull RAST CUSUM scores
  # ----------------------------------------------------------------------------- #
  # Usage:  gengamma_RAST_alt(dataset, estima, rho1)
  # 
  #         dataset: the data
  #         estima: object returned by the function 'RAST_gengamma_estimate'
  #         rho1: intensity of change
  # ----------------------------------------------------------------------------- #
  # Value:  the RAST CUSUM scores
  # ----------------------------------------------------------------------------- #
  
  ndataset <- nrow(dataset)
  lt <- ncol(dataset)
  lb <- lt - 2
  
  
  alpha_0 <- as.numeric(estima[1])
  lambda_0 <-  as.numeric(estima[2])
  beta_0 <- as.numeric(estima[3:lt])
  
  cusum <- vector()
  cusum[1] <- 0
  
  wi <- RAST_score_gengamma(dataset$time, dataset[, - c(1, 2)], dataset$status, rho1, 
                            alpha_0, beta_0, lambda_0)
  for(i in 2:(ndataset + 1)){
    cusum[i] <- max(0, cusum[i - 1] + wi[i - 1])
  }
  
  cusum
  
}
#
#
#



#
#
#
simulation_gengamma_cure50_h <- function(m, n0, n_est, a, b, u, beta, rho1, 
                                         alpha_prob = 1 / 1000, alert = 0, 
                                         h_max = 7.5, h_min = 0.5, 
                                         h_des = h_min + 0.5 * (h_max - h_min), 
                                         max_des = 10, sim_h_est = NULL, resamp = F, 
                                         form = Surv(time, status) ~ V3, n.cov = 1, 
                                         estimates = T) {
  
  # ----------------------------------------------------------------------------- #
  # Title: simulation_gengamma_cure50_h
  # ----------------------------------------------------------------------------- #
  # Author: Jocel?nio W. Oliveira
  # ----------------------------------------------------------------------------- #
  # Description: Function to obtain optimal control limits for data with cure
  #               fraction, generated by the Gengammabull Promotion Time Model
  # ----------------------------------------------------------------------------- #
  # Usage:  simulation_gengamma_cure50_h(m, n0, n_est, a, b, u, beta, rho1, 
  #                                 alpha_prob = 1 / 1000, alert = 0, 
  #                                 h_max = 7.5, h_min = 0.5, 
  #                                 h_des = h_min + 0.5 * (h_max - h_min), 
  #                                 max_des = 10, sim_h_est = NULL, resamp = F, 
  #                                 form = Surv(time, status) ~ V3, n.cov = 1, 
  #                                 estimates = T)
  # 
  #         m: number of replicas to simulate
  #         n0: sample size of in- control data
  #         n_est: training sample size
  #         a: form parameter, alpha
  #         b: scale parameter, lambda
  #         u: value to generate censoring times from a uniform distribution on (0, u)
  #         beta: vector of regression parameters for Promotion Time Model
  #         rho1: the intensity of change in the process
  #         alpha_prob: desired probability of false alarms
  #         alert: number of times to make a sound to alert the conclusion of the
  #                 simulation procedure
  #         h_max: upper boundary for the control limit search
  #         h_min: lower boundary for the control limit search
  #         h_des: value to discard samples (discard if the maximum CUSUM score in
  #                 the sample is less than h_des)
  #         max_des: tolerable maximum total of samples discarded
  #         sim_h_est: object containing results of a previous simulation of the
  #                     control limit, returned by 'simulation_gengamma_cure50_h'
  #         resamp: indicator whether a resampling simulation should be run
  #         form: a formula expression for regression models returned by the Surv 
  #                 function. Example -> Surv(time, status) ~ V3
  #         n.cov: number of covariates
  #         estimates: indicator whether the estimates of parameters should be
  #                     used to simulate data, instead of the original parameters
  # ----------------------------------------------------------------------------- #
  # Value:  dataset0: the training data
  #         COVS = the covariates used to simulate
  #         ncovs = number of covariates
  #         parameters = some parameters of the simulation
  #         RACUF_est = object returned by the function 'RACUF_gengamma_estimate'
  #         RAST_est = object returned by the function 'RAST_gengamma_estimate'
  #         cure_est = estimated cure fraction of the training data
  #         cure = actual cure fraction of the training data
  #         cures_est = mean of the estimated cure fractions for the simulated samples
  #         cures = mean of the actual cure fractions of the simulated samples
  #         censoring0 = censoring proportion in the training data
  #         censoring = mean of the censoring proportions in the simulated samples
  #         discarded = number of samples discarded
  #         RACUF_discarded = number of samples discarded due to error in RACUF
  #         RAST_discarded = number of samples discarded due to error in RAST
  #         RACUF_discarded_min = the minimum CUSUM score of samples discarded for 
  #                                 the RACUF CUSUM chart
  #         RAST_discarded_min = the minimum CUSUM score of samples discarded for 
  #                                 the RAST CUSUM chart
  #         h1_error = indicator of error in calculating h for RACUF CUSUM chart 
  #         h2_error = indicator of error in calculating h for RAST CUSUM chart 
  #         RACUF_minmax = the minimum of the maximum CUSUM scores in each sample 
  #                         for the RACUF CUSUM chart
  #         RAST_minmax = the minimum of the maximum CUSUM scores in each sample 
  #                         for the RAST CUSUM chart
  #         RACUF_ARL0_max = the maximum ARL0 observed for RACUF CUSUM chart
  #         RAST_ARL0_max = the maximum ARL0 observed for RAST CUSUM chart
  #         RACUF_ARL0 = the estimated ARL0 for RACUF CUSUM chart
  #         RAST_ARL0 = the estimated ARL0 for RAST CUSUM chart
  #         h_RACUF = the optimal control limit obtained for RACUF CUSUM chart
  #         h_RAST = the optimal control limit obtained for RACUF CUSUM chart
  #         RESULTS = an object combining results about the resampling technique, 
  #                     with similar information as described above
  #         results = an object combining results about the simulation procedure, 
  #                     with the information described above
  #         hour = the time at which the simulation was completed
  #         time_CUSUM = time spent in data matrix construction and subsequent 
  #                       calculation of CUSUM scores for both charts
  #         time_h = time spent to obtain optimal control limits for both charts
  #         time_simulation = time spent to complete the simulation
  #         time_CUSUM_RES = time spent in data matrix construction and subsequent 
  #                           calculation of CUSUM scores for both charts in the 
  #                           resampling technique
  #         time_h_RES = time spent to obtain optimal control limits for both 
  #                       charts in the resampling technique
  #         time_RES = time spent to complete the resampling technique
  # ----------------------------------------------------------------------------- #
  
  time0 <- NULL
  TIME0 <- NULL
  hour <- NULL
  HOUR <- NULL
  time1 <- NULL
  TIME1 <- NULL
  time2 <- NULL
  TIME2 <-  NULL
  TIME_T <- NULL
  param <- NULL
  n_cov <- NULL
  covs_0 <- NULL
  fractions_cure <- NULL
  cures_est <- NULL
  cens <- NULL
  arl0_target <- 1 / alpha_prob
  error_opt <- 0
  CUSUM_RACUF <- NULL; CUSUM_RAST <- NULL
  ARL0_RACUF <- NULL
  ARL0_RAST <- NULL
  error_h1 <- FALSE; error_h2 <- FALSE
  error_h1.res <- FALSE; error_h2.res <- FALSE
  h1_optimum <- NULL; h2_optimum <- NULL
  h1_optimum.res <- NULL; h2_optimum.res <- NULL
  minmax1 <- Inf; minmax2 <- Inf
  minmax1.res <- Inf; minmax2.res <- Inf
  discard <- 0
  
  M <- NULL
  cured <-  NULL
  
  amostra <- NULL
  delta <- NULL
  censoring <- NULL
  failures <- NULL
  
  dataset_0 <- NULL
  
  estima1 <- NULL
  estima2 <- NULL
  
  beta_ <- NULL
  a_ <- NULL
  b_ <- NULL
  
  est1 <- NULL
  est2 <- NULL
  
  ARLs <- NULL
  
  repeat{
    time0 <- Sys.time()
    print(Sys.time())
    param <- data.frame(replicas = m, samples_size = n0, 
                        training_sample_size = n_est, 
                        alpha = a, lambda = b, tau = u, beta = beta, 
                        alpha.prob = alpha_prob, rho_1 = rho1, h_min = h_min, 
                        h_max = h_max, h_des = h_des, estimates = estimates)
    print(param)
    n_cov <- n.cov #length(beta)
    
    covs_0 <- matrix(rbinom(n_est * n_cov, 1, 0.5), nrow = n_est, ncol = n_cov)
    fractions_cure <- vector()
    cures_est <- vector()
    cens <- vector()
    arl0_target <- 1 / alpha_prob
    error_opt <- 0
    CUSUM_RACUF <- NULL; CUSUM_RAST <- NULL
    error_h1 <- FALSE; error_h2 <- FALSE
    h1_optimum <- NULL; h2_optimum <- NULL
    minmax1 <- Inf; minmax2 <- Inf
    discard <- 0
    
    
    if(is.null(sim_h_est)){
      
      # --------------------------------------------------------- #
      #
      # Training data
      #
      # --------------------------------------------------------- # 
      M <- rpois(n_est, exp(covs_0 %*% beta))
      cured <- sum(M == 0) / n_est
      
      
      # Dados
      amostra <- vector()
      delta <- vector()
      censoring <- runif(n_est, 0, u)
      ind.cure <- which(M == 0)
      ind.susc <- which(M != 0)
      amostra[ind.cure] <- censoring[ind.cure]
      
      delta[ind.cure] <- 0
      
      failures <- vector()
      for(i in ind.susc) failures[i] <- min(rgengammabull(M[i], a, b))
      
      amostra[ind.susc] <- pmin(failures[ind.susc], censoring[ind.susc])
      delta[ind.susc] <- ifelse(failures[ind.susc] <=  censoring[ind.susc], 1, 0)
      
      dataset_0 <- data.frame(cbind(time = amostra, status = delta, covs_0))
      
      
      # -------------------------------------------------- #
      #
      # Estimation - Phase 1
      #
      # -------------------------------------------------- #
      estima1 <- RACUF_gengamma_estimate(dataset_0)
      estima2 <- RAST_gengamma_estimate(dataset_0, form)
      
      
      
    } else{
      # -------------------------------------------------- #
      #
      # Estimation - Phase 1
      #
      # -------------------------------------------------- #
      estima1 <- sim_h_est$RACUF_est
      estima2 <- sim_h_est$RAST_est
      dataset_0 <- sim_h_est$dataset0
    }
    
    beta_ <- estima1$estimates[3:(2 + n_cov)]
    a_ <- estima1$estimates[1]
    b_ <- estima1$estimates[2]  
    
    cat("Initializing samples","\n")
    
    est1 <- as.vector(estima1$estimates)
    est2 <- as.vector(c(estima2$alf, estima2$lam, estima2$bet))
    
    MTPpars <- as.vector(c(a, b, beta))
    ARLs <- .C("simula_lim_gengamma", m = as.integer(m), n0 = as.integer(n0), 
               u = as.double(u), rho1 = as.double(rho1), h = as.double(h_max),
               estima_1 = as.double(est1), estima_2 = as.double(est2), 
               descarte = integer(1), RACUF_ARL0 = double(m), RAST_ARL0 = double(m), 
               RACUF_des = integer(1), RAST_des = integer(1), M = integer(n0), 
               status = double(n0), time = double(n0), covs0 = double(n_cov * n0),
               censuras = double(n0), CUSUM1 = double(1 + n0), CUSUM2 = double(1 + n0), 
               wi1 = double(n0), wi2 = double(n0), matriz1 = double(m * n0), 
               matriz2 = double(m * n0), escore_des = as.double(h_des), 
               cens = double(1), MTP_pars = as.double(MTPpars), 
               RACUF_des_min = double(1), RAST_des_min = double(1), 
               curas = double(1), des_max = as.integer(max_des),
               ncov = as.integer(n_cov), MTP_beta = double(n_cov),
               MTPbeta = double(n_cov), MTFA_beta = double(n_cov), 
               covs = double(n_cov), estimados = as.integer(estimates))
    cat("\n\nTotal of", ARLs$descarte, "samples discarded...\n\n")
    if(ARLs$descarte < max_des) {break}
  }
  
  covars <- matrix(ARLs$covs0, ncol = n_cov)
  fcure_est <- mean(exp(- exp(covars %*% est1[3:(2 + n_cov)])))
  
  time1 <- Sys.time() - time0
  hour <- Sys.time()
  cat("\n\n*** CUSUM calculated","\n","Obtaining control limit h","\n", sep = "")
  
  CUSUM_RACUF <- matrix(ARLs$matriz1, nrow = m, byrow = TRUE)
  CUSUM_RAST <- matrix(ARLs$matriz2, nrow = m, byrow = TRUE)
  minmax1 <- min(apply(CUSUM_RACUF, 1, max))
  minmax2 <- min(apply(CUSUM_RAST, 1, max))
  RAST_discarded_min <- ARLs$RAST_des_min
  RACUF_discarded_min <- ARLs$RACUF_des_min
  
  arl0 <- function(v, h){
    min(which(v > h), n0 + 1)
  }
  
  arl0_med <- function(m, h){
    mean(apply(m, 1, function(x) arl0(x, h)))
  }
  
  function_h1_optimum <- function(h){
    abs(arl0_med(CUSUM_RACUF, h) - arl0_target)
  }
  
  function_h2_optimum <- function(h){
    abs(arl0_med(CUSUM_RAST, h) - arl0_target)
  }
  
  root_h1 <- try(golden.section.search(function_h1_optimum, h_min, h_max, 1e-06))
  root_h2 <- try(golden.section.search(function_h2_optimum, h_min, h_max, 1e-06))
  
  ARL0_RACUF_max <- arl0_med(CUSUM_RACUF, h_max)
  ARL0_RAST_max <- arl0_med(CUSUM_RAST, h_max)
  
  lim_sup_RACUF <- h_max
  lim_sup_RAST <- h_max
  
  if(inherits(root_h1, "try-error")) {
    error_h1 <- TRUE
    h1_optimum <- lim_sup_RACUF
    ARL0_RACUF <- ARL0_RACUF_max
  } else{
    h1_optimum <- root_h1$mini
    ARL0_RACUF <- arl0_med(CUSUM_RACUF, h1_optimum)
  }
  
  if(inherits(root_h2, "try-error")) {
    error_h2 <- TRUE
    h2_optimum <- lim_sup_RAST
    ARL0_RAST <- ARL0_RAST_max
  } else {
    h2_optimum <- root_h2$mini
    ARL0_RAST <- arl0_med(CUSUM_RAST, h2_optimum)
  }
  
  
  
  censoring0 <- 0
  cure0 <- 0
  if(is.null(sim_h_est)){
    censoring0 <- 1 - mean(delta)  
    cure0 <- cured
  } else {
    censoring0 <- sim_h_est$censoring
    cure0 <- sim_h_est$cure
  }
  
  
  results <- cbind(cure_est = estima1$fc,
                   cure = cure0,
                   cures_est = fcure_est,
                   cures = ARLs$curas,
                   censoring0 = censoring0,
                   censoring = ARLs$cens,
                   discarded = ARLs$descarte,
                   RACUF_discarded = ARLs$RACUF_des,
                   RAST_discarded = ARLs$RAST_des,
                   RACUF_discarded_min = ARLs$RACUF_des_min,
                   RAST_discarded_min = ARLs$RAST_des_min,
                   h1_error = error_h1,
                   h2_error = error_h2,
                   RACUF_minmax = minmax1,
                   RAST_minmax = minmax2,
                   RACUF_ARL0_max = ARL0_RACUF_max,
                   RAST_ARL0_max = ARL0_RAST_max,
                   RACUF_ARL0 = ARL0_RACUF,
                   RAST_ARL0 = ARL0_RAST,
                   h_RACUF = h1_optimum,
                   h_RAST = h2_optimum)
  
  
  time2 <- Sys.time() - hour
  time_t <- Sys.time() - time0
  
  cens_res <- NULL
  
  results2 <- NULL
  
  if(resamp){
    
    cat("\n#\n#\n# Initializing resampling...\n#\n#\n")
    
    repeat{
      TIME0 <- Sys.time()
      covari <- as.matrix(dataset_0[, - c(1, 2)])
      ARLS <- .C("simula_lim_res", m = as.integer(m), n0 = as.integer(n0), 
                 u = as.double(u), rho1 = as.double(rho1), h = as.double(h_max),
                 estima_1 = as.double(est1), estima_2 = as.double(est2), 
                 descarte = integer(1), RACUF_ARL0 = double(m), 
                 RAST_ARL0 = double(m), RACUF_des = integer(1), 
                 RAST_des = integer(1), M = integer(n0), 
                 status = as.double(dataset_0$status), 
                 time = as.double(dataset_0$time), covs0 = as.double(covari), 
                 censuras = double(n0), CUSUM1 = double(1 + n0), CUSUM2 = double(1 + n0),
                 wi1 = double(n0), wi2 = double(n0), matriz1 = double(m * n0), 
                 matriz2 = double(m * n0), escore_des = as.double(h_des), 
                 cens = double(1), MTP_pars = as.double(c(a, b, beta)), 
                 RACUF_des_min = double(1), RAST_des_min = double(1), 
                 curas = double(1), des_max = as.integer(max_des), 
                 nest = as.integer(n_est), indices = integer(n0), 
                 ncov = as.integer(n_cov), MTP_beta = double(n_cov),
                 MTPbeta = double(n_cov), MTFA_beta = double(n_cov), 
                 covs = double(n_cov)) 
      
      CUSUM_RACUF <- matrix(ARLS$matriz1, nrow = m, byrow = TRUE)
      CUSUM_RAST <- matrix(ARLS$matriz2, nrow = m, byrow = TRUE)
      minmax1.res <- min(apply(CUSUM_RACUF, 1, max))
      minmax2.res <- min(apply(CUSUM_RAST, 1, max))
      RAST_discarded_min.res <- ARLS$RAST_discarded_min
      RACUF_discarded_min.res <- ARLS$RACUF_discarded_min
      
      cat("\n\n*** CUSUM Calculated. Obtaining control limit h...\n\n")
      TIME1 <- Sys.time() - TIME0
      HOUR <- Sys.time()
      
      root_h1 <- try(golden.section.search(function_h1_optimum, h_min, h_max, 1e-06))
      root_h2 <- try(golden.section.search(function_h2_optimum, h_min, h_max, 1e-06))
      
      ARL0_RACUF.res <- NA
      ARL0_RAST.res <- NA
      
      ARL0_RACUF_max.res <- arl0_med(CUSUM_RACUF, h_max)
      ARL0_RAST_max.res <- arl0_med(CUSUM_RAST, h_max)
      
      
      if(inherits(root_h1, "try-error")) {
        error_h1.res <- TRUE
        h1_optimum.res <- lim_sup_RACUF
        ARL0_RACUF.res <- ARL0_RACUF_max.res
      } else{
        h1_optimum.res <- root_h1$mini
        ARL0_RACUF.res <- arl0_med(CUSUM_RACUF, h1_optimum.res)
      }
      
      if(inherits(root_h2, "try-error")) {
        error_h2.res <- TRUE
        h2_optimum.res <- lim_sup_RAST
        ARL0_RAST.res <- ARL0_RAST_max.res
      } else {
        h2_optimum.res <- root_h2$mini
        ARL0_RAST.res <- arl0_med(CUSUM_RAST, h2_optimum.res)
      }
      
      results2 <- cbind(censoring_res = ARLS$cens,
                        discarded = ARLS$descarte,
                        RACUF_discarded = ARLS$RACUF_des,
                        RAST_discarded = ARLS$RAST_des,
                        h1_error = error_h1.res,
                        h2_error = error_h2.res,
                        RACUF_minmax = minmax1.res,
                        RAST_minmax = minmax2.res,
                        RACUF_ARL0_max = ARL0_RACUF_max.res,
                        RAST_ARL0_max = ARL0_RAST_max.res,
                        RACUF_ARL0 = ARL0_RACUF.res,
                        RAST_ARL0 = ARL0_RAST.res,
                        h_RACUF = h1_optimum.res,
                        h_RAST = h2_optimum.res)
      cat("\n\nTotal of", ARLs$descarte, "samples discarded...\n\n")
      if(ARLS$descarte < max_des) break
    }
    TIME2 <- Sys.time() - HOUR
    TIME_T <- Sys.time() - TIME0
    
    cat("\n\nRange of indexes:\n")
    print(range(ARLS$indices))
    cat("\n")
  }
  
  if(is.null(results2)) results2 <- "Resampling not run"
  
  cat("\n*** Results","\n")
  
  
  
  if(alert!= 0) alert_sound(alert)
  
  return(list(dataset0 = dataset_0,
              COVS = ARLs$covs0,
              ncovs = n_cov,
              parameters = param,
              RACUF_est = estima1,
              RAST_est = estima2,
              cure_est = estima1$fc,
              cure = cure0,
              cures_est = fcure_est,
              cures = ARLs$curas,
              censoring0 = censoring0,
              censoring = ARLs$cens,
              discarded = ARLs$descarte,
              RACUF_discarded = ARLs$RACUF_des,
              RAST_discarded = ARLs$RAST_des,
              RACUF_discarded_min = ARLs$RACUF_des_min,
              RAST_discarded_min = ARLs$RAST_des_min,
              h1_error = error_h1,
              h2_error = error_h2,
              RACUF_minmax = minmax1,
              RAST_minmax = minmax2,
              RACUF_ARL0_max = ARL0_RACUF_max,
              RAST_ARL0_max = ARL0_RAST_max,
              RACUF_ARL0 = ARL0_RACUF,
              RAST_ARL0 = ARL0_RAST,
              h_RACUF = h1_optimum,
              h_RAST = h2_optimum,
              RESULTS = data.frame(results2),
              results = data.frame(results),
              hour = Sys.time(),
              time_CUSUM = time1,
              time_h = time2,
              time_simulation = time_t,
              time_CUSUM_RES = TIME1,
              time_h_RES = TIME2,
              time_RES = TIME_T
  )
  )
  
  
}
#
#
#






#
#
#
simulation_gengamma_cure50_ARL0 <- function(m, n0, n_est, a, b, u, beta, rho1, h, 
                                            estima_1, estima_2, alert = 0, 
                                            dataset_0 = NULL, RES = NULL, n.cov = 1, 
                                            estimates = T, max_des = 10) {
  
  # ----------------------------------------------------------------------------- #
  # Title: simulation_gengamma_cure50_ARL0
  # ----------------------------------------------------------------------------- #
  # Author: Jocel?nio W. Oliveira
  # ----------------------------------------------------------------------------- #
  # Description: Function to estimate the ARL0 for both charts, with data generated
  #               by the Gengammabull Promotion Time Model
  # ----------------------------------------------------------------------------- #
  # Usage:  simulation_gengamma_cure50_ARL0(m, n0, n_est, a, b, u, beta, rho1, h, 
  #                                     estima_1, estima_2, alert = 0, resamp = F, 
  #                                     dataset_0 = NULL, RES = NULL, n.cov = 1, 
  #                                     estimates = T, max_des = 10)
  # 
  #         m: number of replicas to simulate
  #         n0: sample size of in- control data
  #         n_est: training sample size
  #         a: form parameter, alpha
  #         b: scale parameter, lambda
  #         u: fixed value to generate censoring times from a uniform distribution 
  #             on the interval (0, u)
  #         beta: vector of regression parameters for Promotion Time Model
  #         rho1: the intensity of change in the process
  #         h: the optimal control limits to use in the simulation
  #         estima_1: object returned by the function 'RACUF_gengamma_estimate'
  #         estima_2: object returned by the function 'RAST_gengamma_estimate'
  #         alert: number of times to make a sound to alert the conclusion of the
  #                 simulation procedure
  #         dataset_0: training data to consider
  #         RES: the results of previous simulation of control limits by the 
  #               resampling technique (i.e. object RESULTS returned by the 
  #               function 'simulation_gengamma_cure50_h')
  #         n.cov: number of covariates
  #         estimates: indicator whether the estimates of parameters should be
  #                     used to simulate data, instead of the original parameters
  #         max_des: maximum tolerable number of samples discarded
  # ----------------------------------------------------------------------------- #
  # Value:  parameters: some parameters considered in the simulation
  #         limits: the optimal control limits used in the simulation
  #         h_RACUF: the optimal control limit for RACUF CUSUM chart 
  #         h_RAST: the optimal control limit for RAST CUSUM chart
  #         discarded: number of samples discarded
  #         cures: mean of the cure fractions in the simulated samples
  #         cures_est: mean of the estimated cure fractions in the simulated samples
  #         censoring: mean of the censoring proportions in the simulated samples
  #         sd_RACUF: standard deviation of the run length for RACUF CUSUM chart
  #         sd_RAST: standard deviation of the run length for RAST CUSUM chart
  #         NAs_RACUF: number of samples with no signal for RACUF CUSUM chart
  #         NAs_RAST: number of samples with no signal for RAST CUSUM chart
  #         ARL0_RACUF_est: summary of run lengths for RACUF CUSUM via simulation
  #         ARL0_RAST_est: summary of run lengths for RAST CUSUM via simulation
  #         results: an object combining the results of the simulation
  #         hour: the time at which the simulation procedure was completed
  #         time_simulation: time spent to complete the simulation procedure
  # ----------------------------------------------------------------------------- #
  
  time0 <- NULL
  n_cov <- NULL
  param <- NULL
  est1 <- NULL
  est2 <- NULL
  ARLs <- NULL
  
  results <- NULL
  results2 <- NULL
  
  fcure <- NULL
  covars <- NULL
  fcure_est <- NULL
  
  ARL0_RACUF <- NULL
  ARL0_RAST <- NULL
  
  
  arl0_RACUF <- NULL
  arl0_RAST <- NULL
  
  ARLS <- NULL
  
  
  repeat{
    
    print(Sys.time())
    time0 <- Sys.time()
    n_cov <- n.cov
    param <- data.frame(replicas = m, samples_size = n0, 
                        training_sample_size = n_est, alpha = a, lambda = b, 
                        tau = u, beta = beta, rho_1 = rho1, h_RACUF = h[1],
                        h_RAST = h[2], estimates = estimates)
    print(param)
    est1 <- estima_1$estimates
    est2 <- as.numeric(c(estima_2$alf, estima_2$lam, estima_2$bet))
    
    
    ARLs <- .C("simula_ARL0_gengamma", 
               m = as.integer(m), n0 = as.integer(n0), u = as.double(u), 
               rho1 = as.double(rho1), h = as.double(h), estima_1 = as.double(est1),
               estima_2 = as.double(est2), descarte = integer(1), 
               RACUF_ARL0 = double(m), RAST_ARL0 = double(m), RACUF_des = integer(1),
               RAST_des = integer(1), M = integer(n0), status = double(n0), 
               time = double(n0), covs0 = double(n0), censuras = double(n0), 
               CUSUM1 = double(1 + n0), CUSUM2 = double(1 + n0), wi1 = double(n0),
               wi2 = double(n0), MTP_pars = as.double(c(a, b, beta)), 
               cens = double(1), curas = double(1), ncov = as.integer(n_cov), 
               MTP_beta = double(n_cov), MTPbeta = double(n_cov), 
               MTFA_beta = double(n_cov), covs = double(n_cov), 
               estimados = as.integer(estimates), des_max = as.integer(max_des))
    cat("\n\nTotal of", ARLs$descarte, "samples discarded...\n\n")
    if(ARLs$descarte <= max_des) break
  }
  
  fcure <- ARLs$curas
  covars <- matrix(ARLs$covs0, ncol = n_cov)
  fcure_est <- mean(exp(- exp(covars %*% est1[3:(2 + n_cov)])))
  
  ARL0_RACUF <- ARLs$RACUF_ARL0
  ARL0_RAST <- ARLs$RAST_ARL0
  
  
  arl0_RACUF <- summary(ARL0_RACUF)
  arl0_RAST <- summary(ARL0_RAST)
  
  if(alert != 0) alert_sound(alert)
  
  time0 <- Sys.time() - time0
  
  
  
  results <- cbind(h_RACUF = h[1],
                   h_RAST = h[2],
                   discarded = ARLs$descarte,
                   cures = fcure,
                   cures_est = fcure_est,
                   censoring = ARLs$cens,
                   sd_RACUF = sd(ARL0_RACUF),
                   sd_RAST = sd(ARL0_RAST),
                   NAs_RACUF = ARLs$RACUF_des,
                   NAs_RAST = ARLs$RAST_des)
  
  
  
  
  return(list(parameters = param,
              limits = h,
              h_RACUF = h[1],
              h_RAST = h[2],
              discarded = ARLs$descarte,
              cures = fcure,
              cures_est = fcure_est,
              censoring = ARLs$cens,
              sd_RACUF = sd(ARL0_RACUF),
              sd_RAST = sd(ARL0_RAST),
              NAs_RACUF = ARLs$RACUF_des,
              NAs_RAST = ARLs$RAST_des,
              ARL0_RACUF_est = arl0_RACUF,
              ARL0_RAST_est = arl0_RAST,
              results = results,
              hour = Sys.time(),
              time_simulation = time0)
  )
  
  
}
#
#
#


#
#
#
simulation_gengamma_cure50_ARL1 <- function(m, n1, n_est, a, b, u, beta, rho1, lim, 
                                            estima_1, estima_2, alert = 0,
                                            estimates = T, n_cov = 1, 
                                            max_des = 10) {
  
  # ----------------------------------------------------------------------------- #
  # Title: simulation_gengamma_cure50_ARL1
  # ----------------------------------------------------------------------------- #
  # Gengamma
  # ----------------------------------------------------------------------------- #
  # Description: Function to estimate the ARL1 for both charts, with data generated
  #               by the Gengammabull Promotion Time Model
  # ----------------------------------------------------------------------------- #
  # Usage:  simulation_gengamma_cure50_ARL1(m, n1, n_est, a, b, u, beta, rho1, lim, 
  #                                     estima_1, estima_2, alert = 0,
  #                                     estimates = T, n_cov = 1, 
  #                                     max_des = 10)
  # 
  #         m: number of replicas to simulate
  #         n0: sample size of in- control data
  #         n_est: training sample size
  #         a: form parameter, alpha
  #         b: scale parameter, lambda
  #         u: fixed value to generate censoring times from a uniform distribution 
  #             on the interval (0, u)
  #         beta: vector of regression parameters for Promotion Time Model
  #         rho1: the intensity of change in the process
  #         lim: the optimal control limits to use in the simulation
  #         estima_1: object returned by the function 'RACUF_gengamma_estimate'
  #         estima_2: object returned by the function 'RAST_gengamma_estimate'
  #         alert: number of times to make a sound to alert the conclusion of the
  #                 simulation procedure
  #         estimates: indicator whether the estimates of parameters should be
  #                     used to simulate data, instead of the original parameters
  #         n_cov: number of covariates
  #         max_des: maximum tolerable number of samples discarded
  # ----------------------------------------------------------------------------- #
  # Value:  parameters: some parameters considered in the simulation
  #         limits: control limits considered to simulate
  #         cures: mean of the cure fractions in the simulated data
  #         cures_est: mean of the estimated cure fractions in the simulated data
  #         censoring: mean of the censoring proportions in the simulated data
  #         discarded: number of samples discarded
  #         NAs_RACUF: number of samples with no signal for RACUF CUSUM chart
  #         NAs_RAST: number of samples with no signal for RAST CUSUM chart
  #         sd_RACUF: standard deviation of the run lengths for RACUF CUSUM chart
  #         sd_RAST: standard deviation of the run lengths for RAST CUSUM chart
  #         resul_RACUF: summary of the run lengths for RACUF CUSUM chart
  #         resul_RAST: summary of the run lengths for RACUF CUSUM chart
  #         results: an object combining the results of the simulation
  #         hour: the time at which the simulation was completed
  #         time_simulation: time spent to complete the simulation
  # ----------------------------------------------------------------------------- #
  
  param <- NULL
  est1 <- NULL
  est2 <- NULL
  
  ARLs <- NULL
  
  repeat{
    print(Sys.time())
    param <- data.frame(replicas = m, samples_size = n1, 
                        training_sample_size = n_est, alpha = a, lambda = b, 
                        tau = u, beta  =  beta, rho_1 = rho1, h_RACUF = lim[1], 
                        h_RAST = lim[2], estimates = estimates)
    time0  <-  Sys.time()
    print(param)
    
    est1  <-  estima_1$estimates
    est2  <-  as.numeric(estima_2)
    
    ARLs <- .C("simula_ARL1_gengamma", m  =  as.integer(m), n1 = as.integer(n1), 
               u = as.double(u), rho1 = as.double(rho1), h = as.double(lim),
               estima_1 = as.double(est1), estima_2 = as.double(est2), 
               descarte = integer(1), RACUF_ARL1 = double(m), RAST_ARL1 = double(m), 
               RACUF_des = integer(1), RAST_des = integer(1), M = integer(n1), 
               status = double(n1), time = double(n1), covs1 = double(n1),
               censuras = double(n1), CUSUM1 = double(1 + n1), CUSUM2 = double(1 + n1), 
               wi1 = double(n1), wi2 = double(n1), MTP_pars = as.double(c(a, b, beta)),
               cens = double(1), curas = double(1), ncov = as.integer(n_cov),
               MTP_beta = double(n_cov), MTPbeta = double(n_cov), 
               MTFA_beta = double(n_cov), covs = double(n_cov), 
               estimados = as.integer(estimates), des_max = as.integer(max_des))
    cat("\n\nTotal of", ARLs$descarte, "samples discarded...\n\n")
    if(ARLs$descarte <= max_des) break
  }
  
  
  fcure <- ARLs$curas
  
  covars <- matrix(ARLs$covs1, ncol = n_cov)
  fcure_est <- mean(exp(- exp(covars %*% est1[3:(2 + n_cov)])))
  
  arls_RACUF <- ARLs$RACUF_ARL1
  arls_RAST <- ARLs$RAST_ARL1
  
  
  resu_RACUF = summary(arls_RACUF)
  resu_RAST = summary(arls_RAST)
  
  sd_RACUF = sd(arls_RACUF)
  sd_RAST = sd(arls_RAST)
  
  if(alert!= 0) alert_sound(alert)
  time0 = Sys.time() - time0
  
  results = cbind(h_RACUF = lim[1],
                  h_RAST = lim[2],
                  cures = fcure,
                  cures_est = fcure_est,
                  censoring = ARLs$cens,
                  discarded = ARLs$descarte,
                  NAs_RACUF = ARLs$RACUF_des,
                  NAs_RAST = ARLs$RAST_des,
                  sd_RACUF = sd_RACUF,
                  sd_RAST = sd_RAST)
  
  return(list(parameters = param,
              limits = lim,
              cures = fcure,
              cures_est = fcure_est,
              censoring = ARLs$cens,
              discarded = ARLs$descarte,
              NAs_RACUF = ARLs$RACUF_des,
              NAs_RAST = ARLs$RAST_des,
              sd_RACUF = sd_RACUF,
              sd_RAST = sd_RAST,
              resul_RACUF = resu_RACUF,
              resul_RAST = resu_RAST,
              results = results,
              hour = Sys.time(),
              time_simulation = time0)
  )
  
  
  
}
#
#
#




#
#
simulation_gengamma_cure50 = function(rho1, tau, 
                                      h_desc = h_mini + 0.5 * (h_maxi - h_mini),
                                      h_mini = 0.5, h_maxi = 7.5, h_tol = 5, 
                                      ARL0_tol = 50, a_prob = 1 / 1000, max_desc = 10, 
                                      h_est = NULL, resam = F, ARL0_target = 1 / a_prob, 
                                      ncovs = 1, formu = Surv(time, status) ~ V3, 
                                      ARL0 = T, estimates_h = T, estimates_0 = T) {
  
  # ----------------------------------------------------------------------------- #
  # Title: simulation_gengamma_cure50
  # ----------------------------------------------------------------------------- #
  # Gengamma
  # ----------------------------------------------------------------------------- #
  # Description: Function to simulate optimal control limits and after estimate
  #               the corresponding ARL0 for data with cure fraction, generated 
  #               by the Gengammabull Promotion Time Model
  # ----------------------------------------------------------------------------- #
  # Usage:  simulation_gengamma_cure50(rho1, tau, 
  #                               h_desc = h_mini + 0.5 * (h_maxi - h_mini),
  #                               h_mini = 0.5, h_maxi = 7.5, h_tol = 5, 
  #                               ARL0_tol = 50, a_prob = 1 / 1000, max_desc = 10, 
  #                               h_est = NULL, resam = F, ARL0_target = 1 / a_prob, 
  #                               ncovs = 1, formu = Surv(time, status) ~ V3, 
  #                               ARL0 = T, estimates_h = T, estimates_0 = T)
  # 
  #         rho1: the intensity of change in the process
  #         tau: value to generate censoring times from a uniform distribution
  #               in the interval (0, tau)
  #         h_desc: value to discard samples (discard if the maximum CUSUM score
  #                   in the sample is less than h_desc)
  #         h_mini: lower boundary for the control limit search
  #         h_maxi: upper boundary for the control limit search
  #         h_tol: tolerable difference between the desired ARL0 and the estimated
  #                 value observed in the control limit simulation
  #         ARL0_tol: tolerable difference between the desired ARL0 and the 
  #                     estimated value observed in the ARL0 simulation
  #         a_prob: desired false alarms probability (1 / ARL0) 
  #         max_desc: tolerable maximum total of samples discarded
  #         h_est: object containing results of a previous simulation of the
  #                     control limit, returned by 'simulation_gengamma_cure50_h'
  #         resam: indicator whether a resampling simulation should be run
  #         ARL0_target: the desired ARL0
  #         ncovs: number of covariates
  #         formu: a formula expression for regression models returned by the Surv 
  #                   function. Example -> Surv(time, status) ~ V3
  #         ARL0: indicator whether the ARL0 simulation should be run  
  #         estimates_h: indicator whether the estimates of parameters should be 
  #                       used, instead of the true parameters, in the simulation
  #                       of the control limits
  #         estimates_0: indicator whether the estimates of parameters should be 
  #                       used, instead of the true parameters, in the simulation
  #                       of the ARL0
  # ----------------------------------------------------------------------------- #
  # Value:  limit: the object resulted by the control limits simulation
  #         ARL0: the object resulted by the ARL0 simulation
  #         attempts: number of necessary repetitions of the simulation until the
  #                     control limits and the ARL0 are obtained respecting the 
  #                     specified tolerance
  # ----------------------------------------------------------------------------- #
  
  
  cont = 0
  sim_h = NULL
  sim_ARL0 = NULL
  repeat {
    cont = cont + 1
    cat("#\n#\n#\n# Attempt ", cont,"\n#\n#\n#\n")
    
    (sim_h <- 
        simulation_gengamma_cure50_h(nrep_h, n0_h, n_est, alpha, lambda, tau, beta, rho1, 
                                     h_des = h_desc, h_min = h_mini, h_max = h_maxi, 
                                     alpha_prob = a_prob, max_des = max_desc, 
                                     sim_h_est = h_est, resamp = resam, n.cov = ncovs, 
                                     form = formu, estimates = estimates_h))
    print(sim_h)
    
    
    if((abs(ARL0_target - sim_h$RACUF_ARL0) > h_tol) |
       (abs(ARL0_target - sim_h$RAST_ARL0) > h_tol)){
      cat("#\n#\n#\n# Problems in control limit h\n#\n#\n#\n")
      next
    } else{
      if(ARL0){
        
        (sim_ARL0 <- 
           simulation_gengamma_cure50_ARL0(nrep_ARL, n0_ARL, n_est, alpha, lambda, tau,
                                           beta, rho1, c(sim_h$h_RACUF, sim_h$h_RAST),
                                           sim_h$RACUF_est, sim_h$RAST_est,
                                           RES = sim_h$RESULTS,
                                           dataset_0 = sim_h$dataset_0, n.cov = ncovs, 
                                           estimates = estimates_0))
        
        print(sim_ARL0)
        if((abs(ARL0_target - sim_ARL0$ARL0_RACUF_est[4]) > ARL0_tol) |
           (abs(ARL0_target - sim_ARL0$ARL0_RAST_est[4]) > ARL0_tol)){
          cat("#\n#\n#\n# Problems in ARL0\n#\n#\n#\n")
          next
        } else {
          break
        }
      } else {
        cat("\n\n# ARL0 not simulated \n\n")
        break
      }
    }
  }
  return(
    list(limit = sim_h,
         ARL0 = sim_ARL0,
         attempts = cont)
  )
}
#
#




# -------------------------------------------------------------------------------- #
#
# Simulation without cure fraction ----
#
# -------------------------------------------------------------------------------- #

#
#
#
simulation_gengamma_cure00_h <- function(m, n0, n_est, a, b, u, gam, rho1, 
                                         alpha_prob = 1 / 1000, alert = 3, 
                                         h_sup = c(h_max, h_max), h_min = 0.5, 
                                         h_max = 7.5, 
                                         h_des = h_min + 0.5 * (h_max - h_min), 
                                         max_des = 10, sim_h_est = NULL, resamp = F,
                                         form = Surv(time, status) ~ V3, n.cov = 1, 
                                         estimates = T) {
  
  # ----------------------------------------------------------------------------- #
  # Title: simulation_gengamma_cure00_h
  # ----------------------------------------------------------------------------- #
  # Gengamma
  # ----------------------------------------------------------------------------- #
  # Description: Function to obtain optimal control limits for data without cure
  #               fraction, generated by the Gengammabull Accelerated Failure Time Model
  # ----------------------------------------------------------------------------- #
  # Usage:  simulation_gengamma_cure00_h(m, n0, n_est, a, b, u, gam, rho1, 
  #                                 alpha_prob = 1 / 1000, alert = 3, 
  #                                 h_min = 0.5, h_max = 7.5, 
  #                                 h_des = h_min + 0.5 * (h_max - h_min), 
  #                                 max_des = 10, sim_h_est = NULL, resamp = F,
  #                                 form = Surv(time, status) ~ V3, n.cov = 1, 
  #                                 estimates = T)
  # 
  #         m: number of replicas to simulate
  #         n0: sample size of in- control data
  #         n_est: training sample size
  #         a: form parameter, alpha
  #         b: scale parameter, lambda
  #         u: value to generate censoring times from a uniform distribution in
  #             the interval (0, u)
  #         gam: vector of regression parameters for Accelerated Failure Time Model
  #         rho1: the intensity of change in the process
  #         alpha_prob: desired probability of false alarms
  #         alert: number of times to make a sound to alert the conclusion of the
  #                 simulation procedure
  #         h_min: lower boundary for the control limit search
  #         h_max: upper boundary for the control limit search
  #         h_des: value to discard samples (discard if the maximum CUSUM score in
  #                 the sample is less than h_des)
  #         max_des: tolerable maximum total of samples discarded
  #         sim_h_est: object containing results of a previous simulation of the
  #                     control limit, returned by 'simulation_gengamma_cure50_h'
  #         resamp: indicator whether a resampling simulation should be run
  #         form: a formula expression for regression models returned by the Surv 
  #                 function. Example -> Surv(time, status) ~ V3
  #         n.cov: number of covariates
  #         estimates: indicator whether the estimates of parameters should be
  #                     used to simulate data, instead of the original parameters
  # ----------------------------------------------------------------------------- #
  # Value:  dataset0: the training data
  #         covs: the covariates used to simulate
  #         parameters: some parameters of the simulation
  #         RACUF_est: object returned by the function 'RACUF_gengamma_estimate'
  #         RAST_est: object returned by the function 'RAST_gengamma_estimate'
  #         censoring: mean of the censoring proportions in the simulated samples
  #         censoring0: censoring proportion in the training data
  #         cure_est: estimated cure fraction of the training data
  #         cures_est: mean of the estimated cure fractions observed for the 
  #                     simulated samples
  #         discarded: number of samples discarded
  #         h1_error: indicator of error in calculating h for RACUF CUSUM chart 
  #         h2_error: indicator of error in calculating h for RAST CUSUM chart 
  #         RACUF_minmax: the minimum of the maximum CUSUM scores in each sample 
  #                         for the RACUF CUSUM chart
  #         RAST_minmax: the minimum of the maximum CUSUM scores in each sample 
  #                         for the RAST CUSUM chart
  #         RACUF_discarded_min: the minimum CUSUM score of samples discarded for 
  #                                 the RACUF CUSUM chart
  #         RAST_discarded_min: the minimum CUSUM score of samples discarded for 
  #                                 the RAST CUSUM chart
  #         RACUF_ARL0_max: the maximum ARL0 observed for RACUF CUSUM chart
  #         RAST_ARL0_max: the maximum ARL0 observed for RAST CUSUM chart
  #         RACUF_ARL0: the estimated ARL0 for RACUF CUSUM chart
  #         RAST_ARL0: the estimated ARL0 for RAST CUSUM chart
  #         h_RACUF: the optimal control limit obtained for RACUF CUSUM chart
  #         h_RAST: the optimal control limit obtained for RACUF CUSUM chart
  #         RESULTS: an object combining results about the resampling technique, 
  #                     with similar information as described above
  #         results: an object combining results about the simulation procedure, 
  #                     with the information described above
  #         hour: the time at which the simulation was completed
  #         time_CUSUM: time spent in data matrix construction and subsequent 
  #                       calculation of CUSUM scores for both charts
  #         time_h: time spent to obtain optimal control limits for both charts
  #         time_simulation: time spent to complete the simulation
  #         time_CUSUM_RES: time spent in data matrix construction and subsequent 
  #                           calculation of CUSUM scores for both charts in the 
  #                           resampling technique
  #         time_h_RES: time spent to obtain optimal control limits for both 
  #                       charts in the resampling technique
  #         time_RES: time spent to complete the resampling technique
  # ----------------------------------------------------------------------------- #
  
  
  
  time0 <- NULL
  TIME0 <- NULL
  TIME_T <- NULL
  hour <- NULL
  HOUR <- NULL
  time1 <- NULL
  TIME1 <- NULL
  time2 <- NULL
  TIME2 <-  NULL
  
  param <- NULL
  n_cov <- NULL
  covs_0 <- NULL
  fractions_cure <- NULL
  cures_est <- NULL
  cens <- NULL
  arl0_target <- 1 / alpha_prob
  error_opt <- 0
  CUSUM_RACUF <- NULL; CUSUM_RAST <- NULL
  error_h1 <- FALSE; error_h2 <- FALSE
  error_h1.res <- FALSE; error_h2.res <- FALSE
  h1_optimum <- NA; h2_optimum <- NA
  h1_optimum.res <- NA; h2_optimum.res <- NA
  minmax1 <- Inf; minmax2 <- Inf
  minmax1.res <- Inf; minmax2.res <- Inf
  discard <- 0
  
  sigma <- NULL
  mi <- NULL
  
  v <- NULL
  
  amostra <- NULL
  delta <- NULL
  censoring <- NULL
  failures <- NULL
  
  dataset_0 <- NULL
  cens_0 <- NULL
  
  estima1 <- NULL
  estima2 <- NULL
  
  beta_ <- NULL
  a_ <- NULL
  b_ <- NULL
  
  est1 <- NULL
  est2 <- NULL
  
  ARLs <- NULL
  ARLS <- NULL
  
  cures_est <- NULL
  
  sigma_ <- NULL
  mi_ <- NULL
  gam_ <- NULL
  
  
  repeat{
    print(Sys.time())
    time0 <- Sys.time()
    
    param <- data.frame(replicas = m, samples_size = n0, 
                        training_sample_size = n_est,
                        alpha = a, lambda = b, tau = u, gama = gam, 
                        alpha.prob = alpha_prob, rho_1 = rho1,
                        h_min = h_min, h_max = h_max, h_des = h_des, 
                        estimates = estimates, n_covariates = n.cov)
    
    print(param)
    
    n_cov <- n.cov #length(beta)
    
    covs_0 <- matrix(rbinom(n_est * n_cov, 1, 0.5), nrow = n_est, ncol = n_cov)
    
    sigma <- 1 / a # 
    mi <- log(b) # 
    
    cens <- vector()
    arl0_target <- 1 / alpha_prob
    error_opt <- 0
    CUSUM_RACUF <- NULL
    CUSUM_RAST <- NULL
    error_h1 <- FALSE
    error_h2 <- FALSE
    h1_optimum <- NA
    h2_optimum <- NA
    discard <- 0
    minmax1 <- Inf; minmax2 <- Inf
    
    if(is.null(sim_h_est)){
      # -------------------------------------------------------------------------- #
      #                                              
      # Training data
      #                                              
      # -------------------------------------------------------------------------- #
      amostra <- vector() # observed times
      delta <- vector() # censoring / failure indicator
      censoring <- runif(n_est, 0, u)
      
      V <- log(rexp(n_est))
      
      failures <- as.numeric(exp(mi + covs_0 %*% gam + sigma * V)) 
      
      amostra <- pmin(failures, censoring)
      delta <- ifelse(failures <= censoring, 1, 0)
      
      dataset_0 <- data.frame(cbind(time = amostra, status = delta, covs_0))
      cens_0 <- 1 - mean(delta)
      
      # -------------------------------------------------------------------------- #
      #
      # Estimation - Phase 1
      #
      # -------------------------------------------------------------------------- #
      estima1 <- RACUF_gengamma_estimate(dataset_0)
      estima2 <- RAST_gengamma_estimate(dataset_0, form)
      
      cures_est <- estima1$fc
    } else {
      # -------------------------------------------------------------------------- #
      #
      # Estimation - Phase 1
      #
      # -------------------------------------------------------------------------- #
      estima1 <- sim_h_est$RACUF_est
      estima2 <- sim_h_est$RAST_est
      
      dataset_0 <- sim_h_est$dataset0
    }
    
    sigma_ <- 1 / estima2$alf # 
    mi_ <- log(estima2$lam) # 
    gam_ <- - estima2$bet #
    
    
    cat("\nInitializing samples...","\n")
    est1 <- as.numeric(estima1$estimates)
    est2 <- as.numeric(c(estima2$alf, estima2$lam, estima2$bet))
    
    
    ARLs <- .C("simu_lim_gengamma", m = as.integer(m), n0 = as.integer(n0), 
               u = as.double(u), rho1 = as.double(rho1), h = as.double(h_sup),
               estima_1 = as.double(est1), estima_2 = as.double(est2), 
               descarte = integer(1), RACUF_ARL0 = double(m), 
               RAST_ARL0 = double(m), RACUF_des = integer(1), 
               RAST_des = integer(1), M = integer(n0), status = double(n0),
               time = double(n0), covs0 = double(n0 * n_cov), censuras = double(n0),
               CUSUM1 = double(1 + n0), CUSUM2 = double(1 + n0), wi1 = double(n0),
               wi2 = double(n0), matriz1 = double(m * n0), matriz2 = double(m * n0), 
               escore_des = as.double(h_des), cens = double(1), 
               MTFA_pars = as.double(c(a, b, - gam)), RACUF_des_min = double(1), 
               RAST_des_min = double(1), des_max = as.integer(max_des), 
               ncov = as.integer(n_cov), MTP_beta = double(n_cov), 
               MTFAbeta = double(n_cov), MTFA_beta = double(n_cov), 
               covs = double(n_cov), gam = double(n_cov), 
               estimados = as.integer(estimates))
    cat("\n\nTotal of", ARLs$descarte, "samples discarded...\n\n")
    if(ARLs$descarte <= max_des) break
  }
  
  fcure_est <- estima1$fc
  covars <- matrix(ARLs$covs0, ncol = n_cov)
  fcures_est <- mean(exp(- exp(covars %*% est1[- c(1, 2)])))
  
  time1 <- Sys.time() - time0
  hour <- Sys.time()
  cat("\n\n\n*** CUSUM calculated","\n","Obtaining control limit h","\n", sep = "")
  
  CUSUM_RACUF <- matrix(ARLs$matriz1, nrow = m, byrow = TRUE)
  CUSUM_RAST <- matrix(ARLs$matriz2, nrow = m, byrow = TRUE)
  minmax1 <- min(apply(CUSUM_RACUF, 1, max))
  minmax2 <- min(apply(CUSUM_RAST, 1, max))
  
  arl0 <- function(v, h){
    min(which(v > h), n0 + 1)
  }
  
  arl0_med <- function(m, h){
    mean(apply(m, 1, function(x) arl0(x, h)))
  }
  
  function_h1_optimum <- function(h){
    abs(arl0_med(CUSUM_RACUF, h) - arl0_target)
  }
  
  function_h2_optimum <- function(h){
    abs(arl0_med(CUSUM_RAST, h) - arl0_target)
  }
  
  
  root_h1 <- try(golden.section.search(function_h1_optimum, h_min, h_max, 1e-06))
  root_h2 <- try(golden.section.search(function_h2_optimum, h_min, h_max, 1e-06))
  
  ARL0_RACUF <- NA
  ARL0_RAST <- NA
  
  
  ARL0_RACUF_max <- arl0_med(CUSUM_RACUF, h_max)
  ARL0_RAST_max <- arl0_med(CUSUM_RAST, h_max)
  
  
  if(inherits(root_h1, "try-error")) {
    error_h1 <- TRUE
    h1_optimum <- lim_sup_RACUF
    ARL0_RACUF <- ARL0_RACUF_max
  } else{
    h1_optimum <- root_h1$mini
    ARL0_RACUF <- arl0_med(CUSUM_RACUF, h1_optimum)
  }
  
  if(inherits(root_h2, "try-error")) {
    error_h2 <- TRUE
    h2_optimum <- lim_sup_RAST
    ARL0_RAST <- ARL0_RAST_max
  } else {
    h2_optimum <- root_h2$mini
    ARL0_RAST <- arl0_med(CUSUM_RAST, h2_optimum)
  }
  
  
  if(!is.null(sim_h_est)){
    cens_0 <- sim_h_est$censoring0
  }
  
  cat("\n*** Results","\n")
  time2 <- Sys.time() - hour
  time_t <- Sys.time() - time0
  
  results <- cbind(censoring = ARLs$cens,
                   censoring0 = cens_0,
                   cure_est = fcure_est,
                   cures_est = fcures_est,
                   discarded = ARLs$descarte,
                   h1_error = error_h1,
                   h2_error = error_h2,
                   RACUF_minmax = minmax1,
                   RAST_minmax = minmax2,
                   RACUF_discarded_min = ARLs$RACUF_discarded_min,
                   RAST_discarded_min = ARLs$RAST_discarded_min,
                   RACUF_ARL0_max = ARL0_RACUF_max,
                   RAST_ARL0_max = ARL0_RAST_max,
                   RACUF_ARL0 = ARL0_RACUF,
                   RAST_ARL0 = ARL0_RAST,
                   h_RACUF = h1_optimum,
                   h_RAST = h2_optimum)
  
  
  cens_res <- NULL
  
  results2 <- NULL
  
  
  if(resamp){
    
    cat("\n#\n#\n# Initializing resampling...\n#\n#\n")
    
    repeat{
      TIME0 <- Sys.time()
      
      covari <- as.matrix(dataset_0[, - c(1, 2)])
      ARLS <- .C("simula_lim_res", m = as.integer(m), n0 = as.integer(n0), 
                 u = as.double(u), rho1 = as.double(rho1), h = as.double(h_sup),
                 estima_1 = as.double(est1), estima_2 = as.double(est2), 
                 descarte = integer(1), RACUF_ARL0 = double(m), 
                 RAST_ARL0 = double(m), RACUF_des = integer(1), 
                 RAST_des = integer(1), M = integer(n0), 
                 status = as.double(dataset_0$status), 
                 time = as.double(dataset_0$time), 
                 covs0 = as.double(covari), censuras = double(n0), 
                 CUSUM1 = double(1 + n0), CUSUM2 = double(1 + n0), wi1 = double(n0), 
                 wi2 = double(n0), matriz1 = double(m * n0), matriz2 = double(m * n0), 
                 escore_des = as.double(h_des), cens = double(1), 
                 MTP_pars = as.double(c(a, b, - gam)), RACUF_des_min = double(1), 
                 RAST_des_min = double(1), curas = double(1), 
                 des_max = as.integer(max_des), nest = as.integer(n_est), 
                 indices = integer(n0), ncov = as.integer(n_cov), 
                 MTP_beta = double(n_cov), MTPbeta = double(n_cov), 
                 MTFA_beta = double(n_cov), covs = double(n_cov))
      
      CUSUM_RACUF <- matrix(ARLS$matriz1, nrow = m, byrow = TRUE)
      CUSUM_RAST <- matrix(ARLS$matriz2, nrow = m, byrow = TRUE)
      minmax1.res <- min(apply(CUSUM_RACUF, 1, max))
      minmax2.res <- min(apply(CUSUM_RAST, 1, max))
      RAST_discarded_min.res <- ARLS$RAST_discarded_min
      RACUF_discarded_min.res <- ARLS$RACUF_discarded_min
      
      cat("\n\n*** CUSUM calculated. Obtaining h...\n\n")
      TIME1 <- Sys.time() - TIME0
      HOUR <- Sys.time()
      
      root_h1 <- try(golden.section.search(function_h1_optimum, h_min, h_max, 1e-06))
      root_h2 <- try(golden.section.search(function_h2_optimum, h_min, h_max, 1e-06))
      
      ARL0_RACUF.res <- NA
      ARL0_RAST.res <- NA
      
      ARL0_RACUF_max.res <- arl0_med(CUSUM_RACUF, h_max)
      ARL0_RAST_max.res <- arl0_med(CUSUM_RAST, h_max)
      
      
      if(inherits(root_h1, "try-error")) {
        error_h1.res <- TRUE
        h1_optimum.res <- lim_sup_RACUF
        ARL0_RACUF.res <- ARL0_RACUF_max.res
      } else{
        h1_optimum.res <- root_h1$mini
        ARL0_RACUF.res <- arl0_med(CUSUM_RACUF, h1_optimum.res)
      }
      
      if(inherits(root_h2, "try-error")) {
        error_h2.res <- TRUE
        h2_optimum.res <- lim_sup_RAST
        ARL0_RAST.res <- ARL0_RAST_max.res
      } else {
        h2_optimum.res <- root_h2$mini
        ARL0_RAST.res <- arl0_med(CUSUM_RAST, h2_optimum.res)
      }
      
      results2 <- cbind(censoring_res = ARLS$cens,
                        discarded = ARLS$descarte,
                        RACUF_discarded = ARLS$RACUF_des,
                        RAST_discarded = ARLS$RAST_des,
                        h1_error = error_h1.res,
                        h2_error = error_h2.res,
                        RACUF_minmax = minmax1.res,
                        RAST_minmax = minmax2.res,
                        RACUF_ARL0_max = ARL0_RACUF_max.res,
                        RAST_ARL0_max = ARL0_RAST_max.res,
                        RACUF_ARL0 = ARL0_RACUF.res,
                        RAST_ARL0 = ARL0_RAST.res,
                        h_RACUF = h1_optimum.res,
                        h_RAST = h2_optimum.res)
      if(ARLS$descarte < max_des) break
    }
    TIME2 <- Sys.time() - HOUR
    TIME_T <- Sys.time() - TIME0
    
    cat("\n\nRange of indexes:\n")
    print(range(ARLS$indices))
    cat("\n")
  }
  
  if(is.null(results2)) results2 <- "Resampling not run"
  
  cat("\n*** Results","\n")
  
  
  
  alert_sound(alert)
  
  return(list(dataset0 = dataset_0,
              covs = ARLs$covs0,
              parameters = param,
              RACUF_est = estima1,
              RAST_est = estima2,
              censoring = ARLs$cens,
              censoring0 = cens_0,
              cure_est = fcure_est,
              cures_est = fcures_est,
              discarded = ARLs$descarte,
              h1_error = error_h1,
              h2_error = error_h2,
              RACUF_minmax = minmax1,
              RAST_minmax = minmax2,
              RACUF_discarded_min = ARLs$RACUF_des_min,
              RAST_discarded_min = ARLs$RAST_des_min,
              RACUF_ARL0_max = ARL0_RACUF_max,
              RAST_ARL0_max = ARL0_RAST_max,
              RACUF_ARL0 = ARL0_RACUF,
              RAST_ARL0 = ARL0_RAST,
              h_RACUF = h1_optimum,
              h_RAST = h2_optimum,
              RESULTS = data.frame(results2),
              results = data.frame(results),
              hour = Sys.time(),
              time_CUSUM = time1,
              time_h = time2,
              time_simulation = time_t,
              time_CUSUM_RES = TIME1,
              time_h_RES = TIME2,
              time_RES = TIME_T)
  )
  
  
}
#
#
#



#
#
#
simulation_gengamma_cure00_ARL0 <- function(m, n0, n_est, a, b, u, gam, rho1, h,
                                            estima_1, estima_2, alert = 3,
                                            dataset_0 = NULL, RES = NULL, n.cov = 1, 
                                            estimates = T, max_des = 10) {
  
  # ----------------------------------------------------------------------------- #
  # Title: simulation_gengamma_cure00_ARL0
  # ----------------------------------------------------------------------------- #
  # Gengamma
  # ----------------------------------------------------------------------------- #
  # Description: Function to estimate the ARL0 for both charts, with data generated
  #               by the Gengammabull Promotion Time Model
  # ----------------------------------------------------------------------------- #
  # Usage:  simulation_gengamma_cure00_ARL0(m, n0, n_est, a, b, u, gam, rho1, h,
  #                                     estima_1, estima_2, alert = 3, resamp = F, 
  #                                     dataset_0 = NULL, RES = NULL, n.cov = 1, 
  #                                     estimates = T, max_des = 10)
  # 
  #         m: number of replicas to simulate
  #         n0: sample size of in- control data
  #         n_est: training sample size
  #         a: form parameter, alpha
  #         b: scale parameter, lambda
  #         u: fixed value to generate censoring times from a uniform distribution 
  #             on the interval (0, u)
  #         gam: vector of regression parameters for Accelerated Failure Time Model
  #         rho1: the intensity of change in the process
  #         h: the optimal control limits to use in the simulation
  #         estima_1: object returned by the function 'RACUF_gengamma_estimate'
  #         estima_2: object returned by the function 'RAST_gengamma_estimate'
  #         alert: number of times to make a sound to alert the conclusion of the
  #                 simulation procedure
  #         dataset_0: training data to consider
  #         RES: the results of previous simulation of control limits by the 
  #               resampling technique (i.e. object RESULTS returned by the 
  #               function 'simulation_gengamma_cure00_h')
  #         n.cov: number of covariates
  #         estimates: indicator whether the estimates of parameters should be
  #                     used to simulate data, instead of the original parameters
  #         max_des: maximum tolerable number of samples discarded
  # ----------------------------------------------------------------------------- #
  # Value:  parameters: some parameters considered in the simulation
  #         limits: the optimal control limits used in the simulation
  #         h_RACUF: the optimal control limit for RACUF CUSUM chart 
  #         h_RAST: the optimal control limit for RAST CUSUM chart
  #         discarded: number of samples discarded
  #         censoring: mean of the censoring proportions in the simulated samples
  #         cures_est: mean of the estimated cure fractions in the simulated samples
  #         sd_RACUF: standard deviation of the run length for RACUF CUSUM chart
  #         sd_RAST: standard deviation of the run length for RAST CUSUM chart
  #         NAs_RACUF: number of samples with no signal for RACUF CUSUM chart
  #         NAs_RAST: number of samples with no signal for RAST CUSUM chart
  #         ARL0_RACUF_est: summary of run lengths for RACUF CUSUM via simulation
  #         ARL0_RAST_est: summary of run lengths for RAST CUSUM via simulation
  #         results: an object combining the results of the simulation
  #         hour: the time at which the simulation procedure was completed
  #         time_simulation: time spent to complete the simulation procedure
  # ----------------------------------------------------------------------------- #
  
  param <- NULL
  
  time0 <- NULL
  est1 <- NULL
  est2 <- NULL
  
  n_cov <- NULL
  
  ARLs <- NULL
  
  repeat{
    print(Sys.time())
    param <- data.frame(replicas = m, samples_size = n0, 
                        training_sample_size = n_est, 
                        alpha = a, lambda = b, tau = u, gama = gam, rho_1 = rho1, 
                        h_RACUF = h[1], h_RAST = h[2], estimates = estimates)
    print(param)
    time0 <- Sys.time()
    est1 <- estima_1$estimates
    est2 <- as.numeric(c(estima_2$alf, estima_2$lam, estima_2$bet))
    
    n_cov <- n.cov
    
    ARLs <- .C("simu_ARL0_gengamma", m = as.integer(m), n0 = as.integer(n0), 
               u = as.double(u), rho1 = as.double(rho1), h = as.double(h),
               estima_1 = as.double(est1), estima_2 = as.double(est2), 
               descarte = integer(1), RACUF_ARL0 = double(m), RAST_ARL0 = double(m), 
               RACUF_des = integer(1), RAST_des = integer(1), M = integer(n0), 
               status = double(n0), time = double(n0), covs0 = double(n_cov * n0),
               censuras = double(n0), CUSUM1 = double(1 + n0), CUSUM2 = double(1 + n0), 
               wi1 = double(n0), wi2 = double(n0), 
               MTFA_pars = as.double(c(a, b, - gam)), cens = double(1), 
               ncov = as.integer(n_cov), MTP_beta = double(n_cov), 
               MTFAbeta = double(n_cov), MTFA_beta = double(n_cov), 
               covs = double(n_cov), estimados = as.integer(estimates),
               des_max = as.integer(max_des))
    cat("\n\nTotal of", ARLs$descarte, "samples discarded...\n\n")
    if(ARLs$descarte <= max_des) break
  }
  
  fcure_est <- mean(exp(- exp(matrix(ARLs$covs0, ncol = n_cov) %*% est1[- c(1, 2)])))
  
  ARL0_RACUF <- ARLs$RACUF_ARL0
  ARL0_RAST <- ARLs$RAST_ARL0
  
  arl0_RACUF <- summary(ARL0_RACUF)
  arl0_RAST <- summary(ARL0_RAST)
  
  
  
  alert_sound(alert)
  
  time0 <- Sys.time() - time0
  
  
  results <- cbind(h_RACUF = h[1],
                   h_RAST = h[2],
                   discarded = ARLs$descarte,
                   censoring = ARLs$cens,
                   cures_est = fcure_est,
                   sd_RACUF = sd(ARL0_RACUF),
                   sd_RAST = sd(ARL0_RAST),
                   NAs_RACUF = ARLs$RACUF_des,
                   NAs_RAST = ARLs$RAST_des)
  
  return(list(parameters = param,
              limits = h,
              h_RACUF = h[1],
              h_RAST = h[2],
              discarded = ARLs$descarte,
              censoring = ARLs$cens,
              cures_est = fcure_est,
              sd_RACUF = sd(ARL0_RACUF),
              sd_RAST = sd(ARL0_RAST),
              NAs_RACUF = ARLs$RACUF_des,
              NAs_RAST = ARLs$RAST_des,
              ARL0_RACUF_est = arl0_RACUF,
              ARL0_RAST_est = arl0_RAST,
              results = results,
              hour = Sys.time(),
              time_simulation = time0)
  )
  
  
}
#
#
#



#
#
#
simulation_gengamma_cure00_ARL1 <- function(m, n1, n_est, a, b, u, gam, rho1, lim, 
                                            estima_1, estima_2, alert = 3, estimates = T, 
                                            n_cov = 1, max_des = 10) {
  
  # ----------------------------------------------------------------------------- #
  # Title: simulation_gengamma_cure00_ARL1
  # ----------------------------------------------------------------------------- #
  # Gengamma
  # ----------------------------------------------------------------------------- #
  # Description: Function to estimate the ARL1 for both charts, with data generated
  #               by the Gengammabull Accelerated Failure Time Model
  # ----------------------------------------------------------------------------- #
  # Usage:  simulation_gengamma_cure50_ARL1(m, n1, n_est, a, b, u, gam, rho1, lim, 
  #                                     estima_1, estima_2, alert = 3,
  #                                     estimates = T, n_cov = 1)
  # 
  #         m: number of replicas to simulate
  #         n0: sample size of in- control data
  #         n_est: training sample size
  #         a: form parameter, alpha
  #         b: scale parameter, lambda
  #         u: fixed value to generate censoring times from a uniform distribution 
  #             in the interval (0, u)
  #         gam: vector of regression parameters for Accelerated Failure Time Model
  #         rho1: the intensity of change in the process
  #         lim: the optimal control limits to use in the simulation
  #         estima_1: object returned by the function 'RACUF_gengamma_estimate'
  #         estima_2: object returned by the function 'RAST_gengamma_estimate'
  #         alert: number of times to make a sound to alert the conclusion of the
  #                 simulation procedure
  #         estimates: indicator whether the estimates of parameters should be
  #                     used to simulate data, instead of the original parameters
  #         n_cov: number of covariates
  #         max_des: maximum tolerable number of samples discarded
  # ----------------------------------------------------------------------------- #
  # Value:  parameters: some parameters considered in the simulation
  #         limits: control limits considered to simulate
  #         discarded: number of samples discarded
  #         cures_est: mean of the estimated cure fractions in the simulated data
  #         censoring: mean of the censoring proportions in the simulated data
  #         NAs_RACUF: number of samples with no signal for RACUF CUSUM chart
  #         NAs_RAST: number of samples with no signal for RAST CUSUM chart
  #         sd_RACUF: standard deviation of the run lengths for RACUF CUSUM chart
  #         sd_RAST: standard deviation of the run lengths for RAST CUSUM chart
  #         resul_RACUF: summary of the run lengths for RACUF CUSUM chart
  #         resul_RAST: summary of the run lengths for RACUF CUSUM chart
  #         results: an object combining the results of the simulation
  #         hour: the time at which the simulation was completed
  #         time_simulation: time spent to complete the simulation
  # ----------------------------------------------------------------------------- #
  
  param <- NULL
  est1 <- NULL
  est2 <- NULL
  time0 <- NULL
  
  ARLs <- NULL
  
  repeat{
    print(Sys.time())
    param <- data.frame(replicas = m, samples_size = n1, 
                        training_sample_size = n_est,
                        alpha = a, lambda = b, tau = u, gama = gam, rho_1 = rho1,
                        h_RACUF = lim[1], h_RAST = lim[2], estimates = estimates)
    time0 <- Sys.time()
    print(param)
    
    est1 <- estima_1$estimates
    est2 <- as.numeric(estima_2)
    
    ARLs <- .C("simu_ARL1_gengamma", m = as.integer(m), n1 = as.integer(n1),
               u = as.double(u), rho1 = as.double(rho1), h = as.double(lim),
               estima_1 = as.double(est1), estima_2 = as.double(est2), 
               descarte = integer(1), RACUF_ARL1 = double(m), RAST_ARL1 = double(m), 
               RACUF_des = integer(1), RAST_des = integer(1), M = integer(n1), 
               status = double(n1), time = double(n1), covs1 = double(n1),
               censuras = double(n1), CUSUM1 = double(1 + n1), CUSUM2 = double(1 + n1), 
               wi1 = double(n1), wi2 = double(n1), 
               MTFA_pars = as.double(c(a, b, - gam)), cens = double(1), 
               ncov = as.integer(n_cov), MTP_beta = double(n_cov), 
               MTFAbeta = double(n_cov), MTFA_beta = double(n_cov), 
               covs = double(n_cov), gam = double(n_cov), 
               estimados = as.integer(estimates), des_max = as.integer(max_des))
    cat("\n\nTotal of", ARLs$descarte, "samples discarded...\n\n")
    if(ARLs$descarte <= max_des) break
  }
  
  fcure_est <- mean(exp(- exp(ARLs$covs1 * est1[- c(1,2)])))
  
  arls_RACUF <- ARLs$RACUF_ARL1
  arls_RAST <- ARLs$RAST_ARL1
  
  resu_RACUF <- summary(arls_RACUF)
  resu_RAST <- summary(arls_RAST)
  
  sd_RACUF <- sd(arls_RACUF)
  sd_RAST <- sd(arls_RAST)
  
  if(alert!= 0) alert_sound(alert)
  time0 <- Sys.time() - time0
  
  
  results <- cbind(h_RACUF = lim[1],
                   h_RAST = lim[2],
                   discarded = ARLs$descarte,
                   cures_est = fcure_est,
                   censoring = ARLs$cens,
                   NAs_RACUF = ARLs$RACUF_des,
                   NAs_RAST = ARLs$RAST_des,
                   sd_RACUF = sd_RACUF,
                   sd_RAST = sd_RAST)
  
  return(list(parameters = param,
              limits = lim,
              discarded = ARLs$descarte,
              cures_est = fcure_est,
              censoring = ARLs$cens,
              NAs_RACUF = ARLs$RACUF_des,
              NAs_RAST = ARLs$RAST_des,
              sd_RACUF = sd_RACUF,
              sd_RAST = sd_RAST,
              resul_RACUF = resu_RACUF,
              resul_RAST = resu_RAST,
              results = results,
              hour = Sys.time(),
              time_simulation = time0)
  )
  
  
}
#
#
#




#
#
simulation_gengamma_cure00 <- function(rho1, tau, 
                                       h_desc = h_mini + 0.5 * (h_maxi - h_mini), 
                                       h_mini = 0.5, h_maxi = 7.5, h_tol = 5, 
                                       ARL0_tol = 50, a_prob = 1 / 1000, max_desc = 10, 
                                       h_est = NULL, resam = F, ARL0_target = 1 / a_prob,
                                       ARL0 = T, formu = Surv(time, status) ~ V3, 
                                       ncovs = 1, estimates_h = T, estimates_0 = T) {
  
  # ----------------------------------------------------------------------------- #
  # Title: simulation_gengamma_cure00
  # ----------------------------------------------------------------------------- #
  # Author: Jocel?nio W. Oliveira
  # ----------------------------------------------------------------------------- #
  # Description: Function to simulate optimal control limits and after estimate
  #               the corresponding ARL0 for data without cure fraction, generated 
  #               by the Gengammabull Accelerated Failure Time Model
  # ----------------------------------------------------------------------------- #
  # Usage:  simulation_gengamma_cure00(rho1, tau, h_desc = h_mini + 0.5 * (h_maxi - h_mini), 
  #                               h_mini = 0.5, h_maxi = 7.5, h_tol = 2, 
  #                               ARL0_tol = 50, a_prob = 1 / 1000, max_desc = 10, 
  #                               h_est = NULL, resam = F, ARL0_target = 1 / a_prob,
  #                               ARL0 = T, formu = Surv(time, status) ~ V3, ncovs = 1,
  #                               estimates_h = T, estimates_0 = T)
  # 
  #         rho1: the intensity of change in the process
  #         tau: value to generate censoring times from a uniform distribution
  #               in the interval (0, tau)
  #         h_desc: value to discard samples (discard if the maximum CUSUM score
  #                   in the sample is less than h_desc)
  #         h_mini: lower boundary for the control limit search
  #         h_maxi: upper boundary for the control limit search
  #         h_tol: tolerable difference between the desired ARL0 and the estimated
  #                 value observed in the control limit simulation
  #         ARL0_tol: tolerable difference between the desired ARL0 and the 
  #                     estimated value observed in the ARL0 simulation
  #         a_prob: desired false alarms probability (1 / ARL0) 
  #         max_desc: tolerable maximum total of samples discarded
  #         h_est: object containing results of a previous simulation of the
  #                     control limit, returned by 'simulation_gengamma_cure50_h'
  #         resam: indicator whether a resampling simulation should be run
  #         ARL0_target: the desired ARL0
  #         ARL0: indicator whether the ARL0 simulation should be run  
  #         formu: a formula expression for regression models returned by the Surv 
  #                   function. Example -> Surv(time, status) ~ V3
  #         ncovs: number of covariates
  #         estimates_h: indicator whether the estimates of parameters should be 
  #                       used, instead of the true parameters, in the simulation
  #                       of the control limits
  #         estimates_0: indicator whether the estimates of parameters should be 
  #                       used, instead of the true parameters, in the simulation
  #                       of the ARL0
  # ----------------------------------------------------------------------------- #
  # Value:  limit: the object resulted by the control limits simulation
  #         ARL0: the object resulted by the ARL0 simulation
  #         attempts: number of necessary repetitions of the simulation until the
  #                     control limits and the ARL0 are obtained respecting the 
  #                     specified tolerance
  # ----------------------------------------------------------------------------- #
  
  
  cont <- 0
  sim_h <- NULL
  sim_ARL0 <- NULL
  repeat{
    cont <- cont + 1
    cat("#\n#\n#\n# Attempt ", cont,"\n#\n#\n#\n")
    (sim_h <- simulation_gengamma_cure00_h(nrep_h, n0_h, n_est, alpha, lambda, tau, gama, 
                                           rho1, h_des = h_desc, h_min = h_mini, 
                                           h_max = h_maxi, alpha_prob = a_prob, 
                                           max_des = max_desc, sim_h_est = h_est, 
                                           resamp = resam, form = formu, n.cov = ncovs, 
                                           estimates = estimates_h))
    print(sim_h)
    
    if((abs(ARL0_target - sim_h$RACUF_ARL0) > h_tol) |
       (abs(ARL0_target - sim_h$RAST_ARL0) > h_tol)){
      cat("#\n#\n#\n# Problems in control limit h\n#\n#\n#\n")
      next
    } else{
      if(ARL0){
        (sim_ARL0  = 
           simulation_gengamma_cure00_ARL0(nrep_ARL, n0_ARL, n_est, alpha, lambda, tau,
                                           gama, rho1, c(sim_h$h_RACUF, sim_h$h_RAST),
                                           sim_h$RACUF_est, sim_h$RAST_est, 
                                           RES = sim_h$RESULTS, 
                                           dataset_0 = sim_h$dataset0, 
                                           n.cov = ncovs, estimates = estimates_0))
        
        print(sim_ARL0)
        if((abs(ARL0_target - sim_ARL0$ARL0_RACUF_est[4]) > ARL0_tol) |
           (abs(ARL0_target - sim_ARL0$ARL0_RAST_est[4]) > ARL0_tol)){
          cat("#\n#\n#\n# Problems in ARL0 calculation\n#\n#\n#\n")
          next
        } else {
          break
        }
      } else {
        cat("\n\nARL0 not simulated\n\n")
        break
      }
    }
  }
  return(
    list(limit = sim_h,
         ARL0 = sim_ARL0,
         attempts = cont)
  )
}
#
#

#
#
#
#
#
#
#
#
