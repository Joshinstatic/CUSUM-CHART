require(flexsurv)
#
RACUF_gengamma_data <- function(n, a, b, u, beta, intercept = FALSE) {
  
 
  
  n_cov <- length(beta) # total of covariates (or length of vector beta)
  covs <- matrix(rbinom(n * n_cov, 1, 0.5), nrow = n, ncol = n_cov)
  if (intercept) covs[,1] <- rep(1, n)
  M <- rpois(n, exp(covs %*% beta)) # latent variable M (number of causes leading to failure)
  cured <- mean(M == 0) # proportion of cured individuals
  
  # Data
  failures <- vector() # failure times (time until the event occurs)
  censored <- vector() # censored times (time until an individual is censored)
  times <- vector() # the observed times on data (i.e. min(failures, censored))
  delta <- vector() # the censoring indicator (0 = censoring, 1 = failure)
  for(i in 1:n){
    censored[i] <- runif(1, 0, u)
    if(M[i] == 0) {
      failures[i] <- NA
      times[i] <- censored[i] # cured individual
      delta[i] <- 0
    }
    else {
      failures[i] <- min(rgengammabull(M[i], a, b))
      times[i] <- min(failures[i], censored[i]) 
      delta[i] <- ifelse (failures[i] <= censored[i], 1, 0)
    }
  }
  dataset <- data.frame(cbind(time = times, status = delta, covs))
  list(dataset = dataset, cured = cured)
}
#
#




# 
#
RACUF_gengamma_esti <- function(dataset, formu, itera = 0, ini_par = NULL) {
  
 
  covar <- model.matrix(formu, dataset) # covariates model matrix
  
  beta_len <- ncol(covar) # length of the vector beta
  
  par_len <- beta_len + 2 # total of parameters
  
  covar <- as.matrix(covar)
  
  if (!is.null(ini_par)) {
    if (length(ini_par) != par_len) {
      cat("Warning: Initializing vector must have size ",par_len,"\n")
      cat("Continuing calculations with another initial point \n")
    } 
  }
  
  times <- dataset$time
  delta <- dataset$status
  
  n <- length(times)
  
  log_like_marg <- function(theta){
    rho <- exp(theta[1])
    gam <- theta[2]
    beta <- theta[3:par_len]
    
    answer0 <- delta * 
      (covar %*% beta + gam + log(rho * (times)^(rho - 1)) - (times)^rho * exp(gam)) -
      (exp(covar %*% beta) *(1 - exp(-(times)^rho * exp(gam))))
    
    return(sum(answer0))
  }
  
  result_par <- rep(0, par_len)
  if (!is.null(ini_par)) {
    result_par <- ini_par
  }
  
  par.ini <- result_par
  
  # Simulated Annealing
  result_SANN <- NULL
  if (itera > 0) { # improve the initial point with simulated annealing by using optim
    result_SANN <- optim(par.ini, log_like_marg, method="SANN")
  }
  
  if (!is.null(result_SANN)) result_par <- result_SANN$par
  
  
  result_BFGS <- NULL
  
  result_BFGS <- optim(result_par, log_like_marg, control = list(fnscale = -1), 
                       method = "BFGS", hessian = T)
  
  result <- result_BFGS$par
  
  # Original parameters
  a_est = exp(result[1])  # alpha, form parameter
  b_est = exp(-result[2] / a_est) # lambda, scale parameter
  beta_est = result[3:par_len] # beta, regression parameter
  covariate = covar
  cf_est = mean(exp(-exp(covariate %*% beta_est))) # estimated cure fraction
  
  # Return
  list(matrix = covariate, # Model matrix
       result_SANN = result_SANN, # Result of optim, with Simulated Annealing
       result_BFGS = result_BFGS, # Result of optim, with BFGS
       estimate = c(a_est, b_est, beta_est), # Estimates of original parameters
       cure_fraction = (cf_est), # Estimated cure fraction
       max_Log_Lik = result_BFGS$value, # Maximum log-likelihood
       par_ini = par.ini # Initial values for the parameters in optim
  )
  
}
#
#


#
#
RACUF_score_gengamma <- function(t, d, beta, alpha, lambda, rho1, x) {
  

  quant <- (t/lambda)^alpha
  
  res <- d * (-alpha * log(rho1) + quant * (1 - rho1^(-alpha))) -
    exp(x %*% beta) * (-exp(-quant * rho1^(-alpha)) + (exp(-quant)))
  return(as.numeric(res))
}
#
#


#
#
RACUF_cusum <- function(dataset, n0, rho1, lim = 5, formu, iter = 0, 
                        color = 'black', ini_par = NULL) {
  

  n_dataset <- nrow(dataset)
  
  covar <- model.matrix(formu, dataset)
  beta_len <- ncol(covar)
  par_len <- beta_len + 2
  
  covar <- as.matrix(covar)
  
  estimate <- RACUF_gengamma_esti(dataset[(1:n0),], formu, iter, ini_par)
  
  alpha_0 <- estimate$estimate[1]
  lambda_0 <- estimate$estimate[2]
  beta_0 <- estimate$estimate[3:par_len]
  
  cusum <- vector()
  cusum[1] <- 0
  
  wi <- RACUF_score_gengamma(dataset$time, dataset$status, beta_0, 
                             alpha_0, lambda_0, rho1, covar)
  for (i in 2:(n_dataset + 1)) {
    cusum[i] <- max(0, cusum[i - 1] + wi[i - 1])
  }
  lim_y = max(cusum, lim) + 0.1
  
  plot(cusum[2:(n_dataset + 1)], type = "o", pch = 16, cex = 0.1, 
       ylab = expression(Z[i]), xlab = "Observation", cex.lab = 0.8, 
       ylim = c(0, lim_y))
  abline(h = lim, col = color, lwd = 1.2, lty = 2)
  abline(v = n0, col = color, lwd = 1.2, lty = 3)
  
  list(cusum = cusum, 
       cure_fraction_est = estimate$cure_fraction, 
       estimate = estimate
  )
  
}
#
#


#
#
RAST_gengamma_data <- function(n, a, b, u, gam) {
  
  
  n_cov <- length(gam)
  
  sigma <- 1/a  
  mi <- log(b)  
  
  covs <- matrix(rbinom(n*n_cov,1,0.5), nrow=n, ncol=n_cov) # covariates 
  times <- vector() # observed times
  delta <- vector() # failure indicator
  censored <- runif(n, 0, u)
  
  V <- log(rexp(n))
  
  failures <- as.numeric(exp(mi+ gam*covs+sigma*V)) # in control
  
  times <- pmin(failures, censored)
  delta <- ifelse(failures <= censored, 1, 0)
  
  dataset <- data.frame(cbind(time = times, status = delta, covs))
  
  dataset
}
#
#



#
#
RAST_gengamma_esti <- function(dataset, formula) {
  
  MTFA <- survreg(formula, dataset, dist='gengammabull')
  mi.est <- MTFA$coe[1]
  sigma.est <- MTFA$sca
  lambda.est <- exp(mi.est) #scale
  alpha.est <- 1/sigma.est #form
  gama.est <- MTFA$coe[-1]
  beta <- -gama.est
  list(alpha = alpha.est, lambda = lambda.est, beta = beta)
}
#
#



#
#
RAST_score_gengamma <- function(t, u, d, r, a, b, l) {
  
 
  
  return(
    (1 - r^(-a)) * ((t * exp(u %*% b) / l)^a) - d * a * log(r)
  )
}
#
#


#
#
RAST_cusum <- function(dataset, n0, rho1, formula, lim = 5, color = "black") {
  
 
  n_dataset <- nrow(dataset)
  
  covar <- model.matrix(formula, dataset)
  covar <- covar[, -c(1)]
  covar <- as.matrix(covar)
  beta_len <- ncol(covar)
  par_len <- beta_len + 2
  
  estimate <- RAST_gengamma_esti(dataset[(1:n0),], formula)
  
  alpha_0 <- as.numeric(estimate[1])
  lambda_0 <- as.numeric(estimate[2])
  beta_0 <- as.numeric(estimate[3:par_len])
  
  cusum <- vector()
  cusum[1] <- 0
  
  wi <- RAST_score_gengamma(dataset$time, covar, dataset$status, rho1, alpha_0, beta_0, lambda_0)
  for(i in 2:(n_dataset + 1)){
    cusum[i] <- max(0, cusum[i - 1] + wi[i - 1])
  }
  
  lim_y <- max(cusum, lim) + 0.1
  
  plot(cusum[2:(n_dataset + 1)], type = "o", pch = 16, cex = 0.1, cex.lab = 0.8,
       ylab = expression(Z[i]), xlab="Observation", ylim = c(0, lim_y))
  
  abline(h = lim, col = color, lwd = 1.2, lty = 2)
  abline(v = n0, col = color, lwd = 1.2, lty = 3)
  
  list(cusum = cusum, estimate = estimate)
  
}
#
#











#
#
#
golden.section.search <- function(f, lower.bound, upper.bound, tolerance){
  

  golden.ratio <- 2/(sqrt(5) + 1)
  
  ### Use the golden ratio to set the initial test points
  x1 <- upper.bound - golden.ratio * (upper.bound - lower.bound)
  x2 <- lower.bound + golden.ratio * (upper.bound - lower.bound)
  
  ### Evaluate the function at the test points
  f1 <- f(x1)
  f2 <- f(x2)
  
  iteration <- 0
  
  while (abs(upper.bound - lower.bound) > tolerance) {
    iteration <- iteration + 1
    
    if (f2 > f1) {
      # then the minimum is to the left of x2
      # let x2 be the new upper bound
      # let x1 be the new upper test point
      
      ### Set the new upper bound
      upper.bound <- x2
      
      ### Set the new upper test point
      ### Use the special result of the golden ratio
      x2 <- x1
      
      f2 <- f1
      
      ### Set the new lower test point
      x1 <- upper.bound - golden.ratio * (upper.bound - lower.bound)
      
      f1 <- f(x1)
    } else {
      
      # the minimum is to the right of x1
      # let x1 be the new lower bound
      # let x2 be the new lower test point
      
      ### Set the new lower bound
      lower.bound <- x1
      
      ### Set the new lower test point
      x1 <- x2
      
      f1 <- f2
      
      ### Set the new upper test point
      x2 <- lower.bound + golden.ratio * (upper.bound - lower.bound)
      
      f2 <- f(x2)
    }
  }
  
  ### Use the mid-point of the final interval as the estimate of the optimzer
  
  estimated.minimizer <- (lower.bound + upper.bound) / 2
  
  return(list(minimum=estimated.minimizer))
}
#
#
#


#
#
#
gengamma_racuf_alt <- function(dataset, formu, RACUF_est, rho1) {
  
 
  n_dataset <- nrow(dataset)
  
  covar <- model.matrix(formu,dataset)
  beta_len <- ncol(covar)
  par_len <- beta_len+2
  
  covar <- as.matrix(covar)
  
  estimate <- RACUF_est
  
  alpha_0 <- estimate$estimate[1]
  lambda_0 <- estimate$estimate[2]
  beta_0 <- estimate$estimate[3:par_len]
  
  cusum <- vector()
  cusum[1] <- 0
  
  wi <- RACUF_score_gengamma(dataset$time, dataset$status, beta_0, alpha_0,
                             lambda_0, rho1, covar)
  
  for(i in 2:(n_dataset + 1)){
    cusum[i] <- max(0, cusum[i - 1] + wi[i - 1])
  }
  
  cusum[-c(1)]
  
}
#
#
#




#
#
#
RACUF_h <- function(dataset, formu, m, n0, n_est, RACUF_est, rho1, ARL0 = 1000, 
                    h_max = 7, h_min = 1, h_des = 3) {
  
 
  time0 <- Sys.time()
  print(Sys.time())
  
  cens <- vector()
  arl0_target <- ARL0
  error_opt <- 0
  CUSUM_RACUF <- NULL
  error_h1 <- FALSE
  h1_opt <- NA
  minmax1 <- Inf
  discarded <- 0
  
  cat("\n#\n#\n# Initializing samples...","\n#\n#\n")
  j <- 1
  while(j <= m){
    
    indexes <- sample(1:n_est, n0, T)
    
    data_j <- dataset[indexes,]
    
    CUSUM <- gengamma_racuf_alt(data_j, formu, RACUF_est, rho1)
    
    if (max(CUSUM) <= h_des) {
      discarded=discarded+1
      cat("Discarded sample ",discarded,"(RACUF)","\n")
      next
    }
    
    minmax1 <- min(minmax1, max(CUSUM))
    
    cens <- c(cens, 1 - mean(data_j$status))
    
    CUSUM_RACUF <- rbind(CUSUM_RACUF, CUSUM)
    
    cat("Sample ",j," has finished\n")
    j <- j + 1
  }
  
  time1 <- Sys.time() - time0
  hour <- Sys.time()
  cat("*** CUSUM calculated","\n","Initializing optimization of h...","\n",sep="")
  
  arl0 <- function(v,h){
    min(which(v > h), n0 + 1)
  }
  
  arl0_med <- function(m,h){
    mean(apply(m, 1, function(x) arl0(x, h)))
  }
  
  function_h1_opt <- function(h){
    abs(arl0_med(CUSUM_RACUF, h) - arl0_target)
  }
  
  
  root_h1 <- try(golden.section.search(function_h1_opt, h_min, h_max, 1e-06))
  
  
  ARL0_RACUF <- NA
  
  ARL0_RACUF_max <- arl0_med(CUSUM_RACUF, h_max)
  
  
  if (inherits(root_h1, "try-error")) {
    error_h1 <- TRUE
    h1_opt <- lim_sup_RACUF
    ARL0_RACUF <- ARL0_RACUF_max
  } else {
    h1_opt <- root_h1$mini
    ARL0_RACUF <- arl0_med(CUSUM_RACUF, h1_opt)
  }
  
  
  cat("*** Result","\n")
  time2 <- Sys.time() - hour
  time_t <- Sys.time() - time0
  
  return(
    list(RACUF_est = RACUF_est,
         censoring = mean(cens),
         discarded = discarded,
         h1_error = error_h1,
         RACUF_minmax = minmax1,
         RACUF_ARL0_max = ARL0_RACUF_max,
         RACUF_ARL0 = ARL0_RACUF,
         h_RACUF = h1_opt,
         hour = Sys.time(),
         time_CUSUM = time1,
         time_h = time2,
         time = time_t
    )
  )
  
  
}
#
#
#


# 
#
#
gengamma_rast_alt <- function(dataset, form, RAST_est, rho1) {
  
  
  
  n_dataset <- nrow(dataset)
  
  covar <- model.matrix(form,dataset)
  covar <- covar[,-c(1)]
  covar <- as.matrix(covar)
  beta_len <- ncol(covar)
  par_len <- beta_len + 2
  
  estimate <- RAST_est
  
  alpha_0 <- estimate$alpha
  lambda_0 <- estimate$lambda
  beta_0 <- estimate$beta
  
  
  
  lambda.est <- lambda_0 # scale
  alpha.est <- alpha_0 # form
  beta.est <- beta_0
  
  scores <- RAST_score_gengamma(dataset$time, covar, dataset$status, rho1, 
                                alpha.est, beta.est, lambda.est)
  
  # CUSUM
  cusum <- vector()
  cusum[1] <- 0
  for(i in 2:(n_dataset + 1)){
    cusum[i] <- max(0, cusum[i - 1] + scores[i - 1])
  }
  
  cusum[-c(1)]
  
}
#
#
#


#
#
#
RAST_h <- function(dataset, formu, m, n0, n_est, RAST_est, rho1, ARL0 = 1000,
                   h_max = 7, h_min = 1, h_des = 3) {
  
 
  time0 <- Sys.time()
  print(Sys.time())
  
  
  cens <- vector()
  arl0_target <- ARL0
  error_opt <- 0
  CUSUM_RAST <- NULL
  error_h1 <- FALSE
  h1_opt <- NA
  minmax1 <- Inf
  discarded <- 0
  
  cat("\n#\n#\n# Initializing samples...","\n#\n#\n")
  j <- 1
  while(j <= m){
    
    indexes <- sample(1:n_est, n0, T)
    
    dataset_j <- dataset[indexes,]
    
    CUSUM <- gengamma_rast_alt(dataset_j, formu, RAST_est, rho1)
    
    if(max(CUSUM)<=h_des) {
      discarded = discarded + 1
      cat("Discarded sample ", discarded, "(RAST)", "\n")
      next
    }
    
    minmax1 <- min(minmax1, max(CUSUM))
    
    cens = c(cens, 1 - mean(dataset_j$status))
    
    CUSUM_RAST <- rbind(CUSUM_RAST, CUSUM)
    
    cat("Sample ",j," has finished\n")
    j <- j+1
  }
  
  time1 <- Sys.time()-time0
  hour <- Sys.time()
  cat("*** CUSUM calculated","\n","Initializing optimization of h...","\n",sep="")
  
  arl0 <- function(v,h){
    min(which(v>h), n0 + 1)
  }
  
  arl0_med <- function(m,h){
    mean(apply(m, 1, function(x) arl0(x, h)))
  }
  
  function_h1_opt <- function(h){
    abs(arl0_med(CUSUM_RAST, h) - arl0_target)
  }
  
  
  root_h1 <- try(golden.section.search(function_h1_opt, h_min, h_max, 1e-06))
  
  
  ARL0_RAST <- NA
  
  ARL0_RAST_max <- arl0_med(CUSUM_RAST, h_max)
  
  
  if(inherits(root_h1, "try-error")) {
    error_h1 <- TRUE
    h1_opt <- lim_sup_RAST
    ARL0_RAST <- ARL0_RAST_max
  } else{
    h1_opt <- root_h1$mini
    ARL0_RAST <- arl0_med(CUSUM_RAST, h1_opt)
  }
  
  
  cat("*** Result","\n")
  time2 <- Sys.time() - hour
  time_t <- Sys.time() - time0
  
  return(
    list(
      RAST_est = RAST_est,
      censoring = mean(cens),
      discarded = discarded,
      h1_error = error_h1,
      RAST_minmax = minmax1,
      RAST_ARL0_max = ARL0_RAST_max,
      RAST_ARL0 = ARL0_RAST,
      h_RAST = h1_opt,
      hour = Sys.time(),
      time_CUSUM = time1,
      time_h = time2,
      time = time_t
    )
  )
  
  
}
#
#
#






#
#
#
simula_h <- function(dataset, m, n0, n_est, rho1, ARL0 = 1000, h_max = 7.5, h_min = 0.5, 
                     h_des = h_min + 0.5 * (h_max - h_min), max_des = 10, sim_h_est = NULL,
                     form1 = Surv(time, status) ~ V3 + 0, form2 = Surv(time, status) ~ V3,
                     iter = 0, ini_par = NULL, tol = 1e-06, intercept = FALSE) {
  

  TIME <- NULL
  
  HOUR <- NULL
  
  TIME1 <- NULL
  
  TIME2 <- NULL
  param <- NULL
  n_cov <- NULL
  
  cens <- NULL
  arl0_target <- ARL0
  error_opt <- 0
  CUSUM_RACUF <- NULL; CUSUM_RAST <- NULL
  
  error_h1.res <- FALSE; error_h2.res <- FALSE
  
  h1_opt.res <- NA; h2_opt.res <- NA
  
  minmax1.res <- Inf; minmax2.res <- Inf
  discarded <- 0
  
  data_0 <- NULL
  
  estima1 <- NULL
  estima2 <- NULL
  
  est1 <- NULL
  est2 <- NULL
  
  time <- Sys.time()
  print(Sys.time())
  param <- data.frame(replicas = m, sample_size = n0, training_sample_size = n_est, ARL0_target=ARL0, rho_1=rho1,
                      h_min = h_min, h_max = h_max, h_des = h_des)
  print(param)
  
  cens <- vector()
  arl0_target <- ARL0
  error_opt <- 0
  CUSUM_RACUF <- NULL; CUSUM_RAST <- NULL
  
  discarded <- 0
  
  data_0 <- dataset
  
  if(is.null(sim_h_est)){      
    #==================================================#
    #
    # Estimation - Phase 1
    #
    #==================================================#
    estima1 <- RACUF_gengamma_esti(data_0,form1,iter,ini_par)
    estima2 <- RAST_gengamma_esti(data_0,form2)
    
    
    
  } else{
    #====================================================#
    #
    # Estimation - Phase 1
    #
    #====================================================#
    estima1 <- sim_h_est$RACUF_est
    estima2 <- sim_h_est$RAST_est
  }
  
  
  
  est1 <- as.vector(estima1$estima)
  est2 <- as.vector(c(estima2$alpha, estima2$lambda, estima2$beta))
  
  
  cure0 <- estima1$cure_fraction
  censoring0 <- 1 - mean(data_0$status)
  
  n_cov <- ncol(model.matrix(form1, data_0)) 
  
  ARLS <- NULL
  
  cens_res <- NULL
  
  results2 <- NULL
  
  cat("\n#\n#\n# Initializing resampling\n#\n#\n")
  
  repeat { # repeat until optimal control limits are correctly obtained
    TIME <- Sys.time()
    
    covariate <- as.matrix(model.matrix(form1, data_0))
    
    # Calling the compiled C code
    ARLS <- .C("simula_lim_res", m = as.integer(m), n0 = as.integer(n0), 
               rho1 = as.double(rho1), estima_1 = as.double(est1), 
               estima_2 = as.double(est2), descarte = integer(1), RACUF_ARL0 = double(m), 
               RAST_ARL0 = double(m), RACUF_des=integer(1), RAST_des=integer(1), 
               status = as.double(data_0$status), time = as.double(data_0$time), 
               covs0 = as.double(covariate), CUSUM1 = double(1+n0), CUSUM2 = double(1 + n0), 
               wi1 = double(n0), wi2 = double(n0), matriz1 = double(m * n0), 
               matriz2 = double(m * n0), escore_des = as.double(h_des), cens = double(1),
               RACUF_des_min = double(1), RAST_des_min = double(1), 
               des_max = as.integer(max_des), nest = as.integer(n_est),
               indices = integer(n0), ncov = as.integer(n_cov), MTP_beta = double(n_cov),
               MTFA_beta = double(n_cov), covs = double(n_cov), 
               COVS = double(n_cov-as.integer(intercept)), intercept = as.integer(intercept)
    )
    if (ARLS$descarte < max_des) break
  }
  
  CUSUM_RACUF <- matrix(ARLS$matriz1, nrow = m, byrow = TRUE)
  CUSUM_RAST <- matrix(ARLS$matriz2, nrow = m, byrow = TRUE)
  minmax1.res <- min(apply(CUSUM_RACUF, 1, max))
  minmax2.res <- min(apply(CUSUM_RAST, 1, max))
  RAST_des_min.res <- ARLS$RAST_des_min
  RACUF_des_min.res <- ARLS$RACUF_des_min
  
  cat("\n\n*** CUSUM Calculated. Obtaining h...\n\n")
  TIME1 <- Sys.time() - TIME
  HOUR <- Sys.time()
  
  
  arl0 <- function(v, h) {
    min(which(v > h), n0 + 1)
  }
  
  arl0_med <- function(m, h){
    mean(apply(m, 1, function(x) arl0(x, h)))
  }
  
  function_h1_opt <- function(h) {
    abs(arl0_med(CUSUM_RACUF, h) - arl0_target)
  }
  
  function_h2_opt <- function(h) {
    abs(arl0_med(CUSUM_RAST,h) - arl0_target)
  }
  
  
  root_h1 <- try(golden.section.search(function_h1_opt, h_min, h_max, tol))
  root_h2 <- try(golden.section.search(function_h2_opt, h_min, h_max, tol))
  
  ARL0_RACUF.res <- NA
  ARL0_RAST.res <- NA
  
  ARL0_RACUF_max.res <- arl0_med(CUSUM_RACUF, h_max)
  ARL0_RAST_max.res <- arl0_med(CUSUM_RAST, h_max)
  
  
  if(inherits(root_h1, "try-error")) {
    error_h1.res <- TRUE
    h1_opt.res <- lim_sup_RACUF
    ARL0_RACUF.res <- ARL0_RACUF_max.res
  } else{
    h1_opt.res <- root_h1$mini
    ARL0_RACUF.res <- arl0_med(CUSUM_RACUF, h1_opt.res)
  }
  
  if(inherits(root_h2, "try-error")) {
    error_h2.res <- TRUE
    h2_opt.res <- lim_sup_RAST
    ARL0_RAST.res <- ARL0_RAST_max.res
  } else {
    h2_opt.res <- root_h2$mini
    ARL0_RAST.res <- arl0_med(CUSUM_RAST, h2_opt.res)
  }
  
  results2 <- cbind(censoring_res = ARLS$cens,
                    discarded = ARLS$descarte,
                    RACUF_discarded = ARLS$RACUF_des,
                    RAST_discarded = ARLS$RAST_des,
                    h1_error = error_h1.res,
                    h2_error = error_h2.res,
                    RACUF_minmax = minmax1.res,
                    RAST_minmax = minmax2.res,
                    RACUF_ARL0_max = ARL0_RACUF_max.res,
                    RAST_ARL0_max = ARL0_RAST_max.res,
                    RACUF_ARL0 = ARL0_RACUF.res,
                    RAST_ARL0 = ARL0_RAST.res,
                    h_RACUF = h1_opt.res,
                    h_RAST = h2_opt.res)
  
  
  
  TIME2 <- Sys.time() - HOUR
  TIME_t <- Sys.time() - TIME  
  
  if(is.null(results2)) results2 <- "Resampling not run"
  
  cat("\n*** Result","\n")
  
  return(list(data0 = data_0,
              COVS = ARLS$covs0,
              ncovs = n_cov,
              parameters = param,
              RACUF_est = estima1,
              RAST_est = estima2,
              censoring0 = censoring0,
              censoring = ARLS$cens,
              discarded = ARLS$descarte,
              RACUF_discarded = ARLS$RACUF_des,
              RAST_discarded = ARLS$RAST_des,
              RACUF_discarded_min = ARLS$RACUF_des_min,
              RAST_discarded_min = ARLS$RAST_des_min,
              h1_error = error_h1.res,
              h2_error = error_h2.res,
              RACUF_minmax = minmax1.res,
              RAST_minmax = minmax2.res,
              RACUF_ARL0_max = ARL0_RACUF_max.res,
              RAST_ARL0_max = ARL0_RAST_max.res,
              RACUF_ARL0 = ARL0_RACUF.res,
              RAST_ARL0 = ARL0_RAST.res,
              h_RACUF = h1_opt.res,
              h_RAST = h2_opt.res,
              RESULTS = data.frame(results2),
              hour = Sys.time(),
              time_CUSUM_RES = TIME1,
              time_h_RES = TIME2,
              time_RES = TIME_t
  )
  )
  
  
}
#
#
#
